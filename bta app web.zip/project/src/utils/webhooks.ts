export const sendWebhook = async (endpoint: string, data: any) => {
  try {
    // Simulate webhook call - replace with actual n8n endpoint
    console.log('Sending webhook to:', endpoint, data);
    
    // For now, we'll simulate a successful response
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({ success: true, message: 'Webhook sent successfully' });
      }, 1000);
    });
  } catch (error) {
    console.error('Webhook error:', error);
    throw error;
  }
};

export const webhookEndpoints = {
  newTrade: 'https://your-n8n-instance.com/webhook/new-trade',
  closeTrade: 'https://your-n8n-instance.com/webhook/close-trade',
  tradeAnalysis: 'https://your-n8n-instance.com/webhook/trade-analysis',
  aiQuestion: 'https://your-n8n-instance.com/webhook/ai-question',
  profileUpdate: 'https://your-n8n-instance.com/webhook/profile-update'
};