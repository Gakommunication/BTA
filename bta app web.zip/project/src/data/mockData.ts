import { Trade, AIMessage, UserProfile, ForexPair, AccountInfo, ChartData, TradeAnalysis } from '../types';

export const mockForexPairs: ForexPair[] = [
  {
    symbol: 'EURUSD',
    name: 'Euro vs US Dollar',
    bid: 1.0845,
    ask: 1.0847,
    spread: 0.2,
    change: 0.0012,
    changePercent: 0.11,
    high: 1.0856,
    low: 1.0832
  },
  {
    symbol: 'GBPUSD',
    name: 'British Pound vs US Dollar',
    bid: 1.2634,
    ask: 1.2636,
    spread: 0.2,
    change: -0.0023,
    changePercent: -0.18,
    high: 1.2667,
    low: 1.2621
  },
  {
    symbol: 'USDJPY',
    name: 'US Dollar vs Japanese Yen',
    bid: 149.82,
    ask: 149.85,
    spread: 0.3,
    change: 0.45,
    changePercent: 0.30,
    high: 150.12,
    low: 149.23
  },
  {
    symbol: 'USDCHF',
    name: 'US Dollar vs Swiss Franc',
    bid: 0.8756,
    ask: 0.8758,
    spread: 0.2,
    change: -0.0008,
    changePercent: -0.09,
    high: 0.8771,
    low: 0.8745
  },
  {
    symbol: 'AUDUSD',
    name: 'Australian Dollar vs US Dollar',
    bid: 0.6523,
    ask: 0.6525,
    spread: 0.2,
    change: 0.0015,
    changePercent: 0.23,
    high: 0.6534,
    low: 0.6508
  },
  {
    symbol: 'USDCAD',
    name: 'US Dollar vs Canadian Dollar',
    bid: 1.3678,
    ask: 1.3680,
    spread: 0.2,
    change: -0.0012,
    changePercent: -0.09,
    high: 1.3695,
    low: 1.3665
  }
];

export const mockAccountInfo: AccountInfo = {
  balance: 10000.00,
  equity: 10247.50,
  margin: 1250.00,
  freeMargin: 8997.50,
  marginLevel: 819.8
};

export const mockOpenTrades: Trade[] = [
  {
    id: '1',
    date: new Date('2024-01-15T10:30:00'),
    pair: 'EURUSD',
    amount: 10000,
    volume: 0.1,
    direction: 'buy',
    reason: 'Breakout above resistance',
    status: 'open',
    entryPrice: 1.0832,
    currentPrice: 1.0845,
    stopLoss: 1.0810,
    takeProfit: 1.0880,
    pnl: 13.00,
    orderType: 'market',
    comment: 'ECB dovish stance'
  },
  {
    id: '2',
    date: new Date('2024-01-15T14:15:00'),
    pair: 'GBPUSD',
    amount: 15000,
    volume: 0.15,
    direction: 'sell',
    reason: 'Bearish divergence on RSI',
    status: 'open',
    entryPrice: 1.2658,
    currentPrice: 1.2634,
    stopLoss: 1.2685,
    takeProfit: 1.2600,
    pnl: 36.00,
    orderType: 'market',
    comment: 'Brexit concerns'
  }
];

export const mockClosedTrades: Trade[] = [
  {
    id: '3',
    date: new Date('2024-01-14T09:45:00'),
    pair: 'USDJPY',
    amount: 20000,
    volume: 0.2,
    direction: 'buy',
    reason: 'Fed hawkish stance',
    status: 'win',
    entryPrice: 149.25,
    stopLoss: 148.90,
    takeProfit: 149.80,
    result: 110.00,
    orderType: 'market',
    comment: 'Strong USD momentum',
    analysis: {
      id: 'a1',
      tradeId: '3',
      rating: 4,
      emotionalState: 'calm',
      reason: 'Clear technical setup with fundamental support',
      lesson: 'Patience paid off, waited for confirmation before entry',
      attachments: [],
      createdAt: new Date('2024-01-14T16:30:00')
    }
  },
  {
    id: '4',
    date: new Date('2024-01-13T15:20:00'),
    pair: 'EURUSD',
    amount: 12000,
    volume: 0.12,
    direction: 'sell',
    reason: 'Double top formation',
    status: 'loss',
    entryPrice: 1.0875,
    stopLoss: 1.0895,
    takeProfit: 1.0835,
    result: -24.00,
    orderType: 'market',
    comment: 'Failed pattern'
  }
];

export const mockTrades: Trade[] = [...mockOpenTrades, ...mockClosedTrades];

export const mockAIMessages: AIMessage[] = [
  {
    id: '1',
    content: 'Excellente prise de position sur EUR/USD ! Votre analyse technique était parfaite. Le breakout au-dessus de la résistance à 1.0830 confirme la tendance haussière.',
    timestamp: new Date(),
    type: 'trade',
    tradeId: '1'
  },
  {
    id: '2',
    content: 'Attention : vous avez maintenant 2 positions ouvertes. Surveillez votre exposition au risque et respectez votre money management.',
    timestamp: new Date(Date.now() - 1800000),
    type: 'warning'
  },
  {
    id: '3',
    content: 'Félicitations pour votre trade gagnant sur USD/JPY ! +110$ de profit. Votre patience et votre discipline sont remarquables.',
    timestamp: new Date(Date.now() - 3600000),
    type: 'motivation',
    tradeId: '3'
  }
];

export const mockProfile: UserProfile = {
  level: 'intermediate',
  dailyGoal: 100,
  weeklyGoal: 500,
  goalType: 'daily',
  tradingStyle: 'intraday'
};

export const generateMockChartData = (pair: string, timeframe: string): ChartData[] => {
  const data: ChartData[] = [];
  const basePrice = mockForexPairs.find(p => p.symbol === pair)?.bid || 1.0000;
  const now = new Date();
  
  // Generate 100 candles
  for (let i = 99; i >= 0; i--) {
    const timestamp = new Date(now.getTime() - i * getTimeframeMinutes(timeframe) * 60000);
    const volatility = 0.001;
    const change = (Math.random() - 0.5) * volatility;
    const open = basePrice + change;
    const close = open + (Math.random() - 0.5) * volatility;
    const high = Math.max(open, close) + Math.random() * volatility * 0.5;
    const low = Math.min(open, close) - Math.random() * volatility * 0.5;
    
    data.push({
      timestamp,
      open,
      high,
      low,
      close,
      volume: Math.random() * 1000
    });
  }
  
  return data;
};

const getTimeframeMinutes = (timeframe: string): number => {
  switch (timeframe) {
    case 'M1': return 1;
    case 'M5': return 5;
    case 'M15': return 15;
    case 'H1': return 60;
    case 'H4': return 240;
    case 'D1': return 1440;
    default: return 60;
  }
};

export const currencyPairs = mockForexPairs.map(pair => pair.symbol);

export const tradingStyles = [
  { value: 'scalping', label: 'Scalping' },
  { value: 'intraday', label: 'Intraday' },
  { value: 'swing', label: 'Swing Trading' },
  { value: 'position', label: 'Position Trading' }
];

export const tradingLevels = [
  { value: 'beginner', label: 'Débutant' },
  { value: 'intermediate', label: 'Intermédiaire' },
  { value: 'advanced', label: 'Avancé' }
];

export const emotionalStates = [
  { value: 'calm', label: 'Calme', color: 'green' },
  { value: 'stressed', label: 'Stressé', color: 'orange' },
  { value: 'euphoric', label: 'Euphorique', color: 'blue' },
  { value: 'frustrated', label: 'Frustré', color: 'red' }
];