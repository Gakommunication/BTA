import React, { useState } from 'react';
import { TrendingUp, TrendingDown, Calendar, Filter } from 'lucide-react';
import { Trade } from '../types';

interface HistoryProps {
  trades: Trade[];
}

const History: React.FC<HistoryProps> = ({ trades }) => {
  const [activeFilter, setActiveFilter] = useState('sem');
  const sortedTrades = [...trades].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  
  const totalResult = sortedTrades.reduce((sum, trade) => sum + (trade.result || 0), 0);
  const winningTrades = sortedTrades.filter(t => (t.result || 0) > 0);
  const losingTrades = sortedTrades.filter(t => (t.result || 0) < 0);

  const filters = [
    { id: 'jour', label: 'Jour' },
    { id: 'sem', label: 'Sem' },
    { id: 'mois', label: 'Mois' },
    { id: 'custom', label: 'Personnaliser' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 pb-20">
      {/* Header */}
      <div className="px-6 pt-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-white mb-2">Historique</h1>
          </div>
          <button className="w-10 h-10 bg-gray-800/50 backdrop-blur-sm rounded-xl flex items-center justify-center border border-gray-700/50">
            <Filter className="h-5 w-5 text-white" />
          </button>
        </div>

        {/* Filter Tabs */}
        <div className="flex space-x-2 mb-8">
          {filters.map((filter) => (
            <button
              key={filter.id}
              onClick={() => setActiveFilter(filter.id)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 ${
                activeFilter === filter.id
                  ? 'bg-pink-600 text-white'
                  : 'text-gray-400 hover:text-white hover:bg-gray-800/50'
              }`}
            >
              {filter.label}
            </button>
          ))}
        </div>

        {/* Result Summary */}
        <div className="text-center mb-8">
          <p className="text-gray-400 mb-2">Résultat</p>
          <div className={`text-4xl font-bold mb-2 ${totalResult >= 0 ? 'text-green-400' : 'text-red-400'}`}>
            {totalResult >= 0 ? '+' : ''}{totalResult.toLocaleString('fr-FR')} €
          </div>
          <div className="flex items-center justify-center space-x-4 text-sm">
            <span className="text-green-400">↗ {winningTrades.length} gains</span>
            <span className="text-red-400">↘ {losingTrades.length} pertes</span>
          </div>
        </div>

        {/* Performance Cards */}
        <div className="grid grid-cols-2 gap-4 mb-8">
          {/* Gains */}
          <div className="bg-green-500/10 border border-green-500/20 rounded-2xl p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-green-400 font-semibold text-sm">Mes gains</h3>
              <TrendingUp className="h-4 w-4 text-green-400" />
            </div>
            
            <div className="space-y-3">
              {winningTrades.slice(0, 2).map((trade) => (
                <div key={trade.id} className="bg-green-500/5 rounded-xl p-3">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-white font-medium text-sm">{trade.pair}</span>
                    <span className="text-green-400 font-bold text-sm">
                      +€{(trade.result || 0).toLocaleString('fr-FR')}
                    </span>
                  </div>
                  <div className="h-8">
                    <svg className="w-full h-full" viewBox="0 0 100 30">
                      <path
                        d="M0,25 Q25,15 50,10 T100,5"
                        stroke="#10B981"
                        strokeWidth="2"
                        fill="none"
                      />
                    </svg>
                  </div>
                  <div className="text-green-300 text-xs">
                    +{((trade.result || 0) / trade.amount * 100).toFixed(1)}%
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Losses */}
          <div className="bg-red-500/10 border border-red-500/20 rounded-2xl p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-red-400 font-semibold text-sm">Mes pertes</h3>
              <TrendingDown className="h-4 w-4 text-red-400" />
            </div>
            
            {losingTrades.length > 0 ? (
              <div className="bg-red-500/5 rounded-xl p-3">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-white font-medium text-sm">{losingTrades[0].pair}</span>
                  <span className="text-red-400 font-bold text-sm">
                    €{(losingTrades[0].result || 0).toLocaleString('fr-FR')}
                  </span>
                </div>
                <div className="h-8">
                  <svg className="w-full h-full" viewBox="0 0 100 30">
                    <path
                      d="M0,5 Q25,15 50,20 T100,25"
                      stroke="#EF4444"
                      strokeWidth="2"
                      fill="none"
                    />
                  </svg>
                </div>
                <div className="text-red-300 text-xs">
                  {((losingTrades[0].result || 0) / losingTrades[0].amount * 100).toFixed(1)}%
                </div>
              </div>
            ) : (
              <div className="text-center py-4">
                <p className="text-gray-400 text-sm">Aucune perte</p>
              </div>
            )}
          </div>
        </div>

        {/* Transaction History */}
        <div className="bg-gray-800/30 backdrop-blur-sm rounded-2xl border border-gray-700/30 overflow-hidden">
          <div className="p-4 border-b border-gray-700/30">
            <h3 className="text-white font-semibold">Historique des transactions</h3>
          </div>
          
          <div className="divide-y divide-gray-700/30">
            {sortedTrades.map((trade) => (
              <div key={trade.id} className="p-4 hover:bg-gray-700/20 transition-colors">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                      (trade.result || 0) >= 0 ? 'bg-green-500/20' : 'bg-red-500/20'
                    }`}>
                      {trade.direction === 'buy' ? (
                        <TrendingUp className={`h-5 w-5 ${(trade.result || 0) >= 0 ? 'text-green-400' : 'text-red-400'}`} />
                      ) : (
                        <TrendingDown className={`h-5 w-5 ${(trade.result || 0) >= 0 ? 'text-green-400' : 'text-red-400'}`} />
                      )}
                    </div>
                    <div>
                      <h4 className="text-white font-semibold">{trade.pair}</h4>
                      <div className="flex items-center space-x-2 text-xs text-gray-400">
                        <Calendar className="h-3 w-3" />
                        <span>{new Date(trade.date).toLocaleDateString('fr-FR')}</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className={`font-bold ${
                      (trade.result || 0) >= 0 ? 'text-green-400' : 'text-red-400'
                    }`}>
                      {(trade.result || 0) >= 0 ? '+' : ''}€{(trade.result || 0).toLocaleString('fr-FR')}
                    </p>
                    <p className="text-gray-400 text-sm">€{trade.amount}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default History;