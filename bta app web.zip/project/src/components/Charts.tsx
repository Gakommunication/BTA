import React, { useState } from 'react';
import { BarChart3, TrendingUp, TrendingDown } from 'lucide-react';
import { Timeframe, Trade } from '../types';
import { generateMockChartData, mockForexPairs } from '../data/mockData';

interface ChartsProps {
  selectedPair: string;
  onSelectPair: (pair: string) => void;
  openTrades: Trade[];
}

const Charts: React.FC<ChartsProps> = ({ selectedPair, onSelectPair, openTrades }) => {
  const [timeframe, setTimeframe] = useState<Timeframe>('H1');
  
  const timeframes: Timeframe[] = ['M1', 'M5', 'M15', 'H1', 'H4', 'D1'];
  const chartData = generateMockChartData(selectedPair, timeframe);
  const pairData = mockForexPairs.find(p => p.symbol === selectedPair);
  const pairTrades = openTrades.filter(t => t.pair === selectedPair);

  const renderCandlestick = (data: any, index: number, maxPrice: number, minPrice: number) => {
    const x = (index / chartData.length) * 280 + 10;
    const priceRange = maxPrice - minPrice;
    const yOpen = 180 - ((data.open - minPrice) / priceRange) * 160;
    const yClose = 180 - ((data.close - minPrice) / priceRange) * 160;
    const yHigh = 180 - ((data.high - minPrice) / priceRange) * 160;
    const yLow = 180 - ((data.low - minPrice) / priceRange) * 160;
    
    const isGreen = data.close > data.open;
    const bodyHeight = Math.abs(yClose - yOpen);
    const bodyY = Math.min(yOpen, yClose);

    return (
      <g key={index}>
        {/* Wick */}
        <line
          x1={x}
          y1={yHigh}
          x2={x}
          y2={yLow}
          stroke={isGreen ? '#10B981' : '#EF4444'}
          strokeWidth="1"
        />
        {/* Body */}
        <rect
          x={x - 1}
          y={bodyY}
          width="2"
          height={Math.max(bodyHeight, 1)}
          fill={isGreen ? '#10B981' : '#EF4444'}
        />
      </g>
    );
  };

  const maxPrice = Math.max(...chartData.map(d => d.high));
  const minPrice = Math.min(...chartData.map(d => d.low));

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 pb-20">
      <div className="px-6 pt-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-white mb-2">Graphiques</h1>
            <p className="text-gray-400">Analyse technique</p>
          </div>
          <div className="w-12 h-12 bg-gradient-to-r from-pink-600 to-purple-600 rounded-2xl flex items-center justify-center">
            <BarChart3 className="h-6 w-6 text-white" />
          </div>
        </div>

        {/* Pair Selector */}
        <div className="bg-gray-800/30 backdrop-blur-sm rounded-2xl border border-gray-700/30 p-4 mb-6">
          <select
            value={selectedPair}
            onChange={(e) => onSelectPair(e.target.value)}
            className="w-full bg-gray-700/50 border border-gray-600/30 rounded-xl px-4 py-3 text-white focus:border-pink-500/50 focus:outline-none"
          >
            {mockForexPairs.map((pair) => (
              <option key={pair.symbol} value={pair.symbol} className="bg-gray-800">
                {pair.symbol} - {pair.name}
              </option>
            ))}
          </select>
        </div>

        {/* Timeframe Selector */}
        <div className="flex space-x-2 mb-6 overflow-x-auto">
          {timeframes.map((tf) => (
            <button
              key={tf}
              onClick={() => setTimeframe(tf)}
              className={`px-4 py-2 rounded-xl text-sm font-medium transition-all duration-200 whitespace-nowrap ${
                timeframe === tf
                  ? 'bg-pink-600 text-white'
                  : 'bg-gray-800/50 text-gray-400 hover:text-white hover:bg-gray-700/50'
              }`}
            >
              {tf}
            </button>
          ))}
        </div>

        {/* Price Info */}
        {pairData && (
          <div className="bg-gray-800/30 backdrop-blur-sm rounded-2xl border border-gray-700/30 p-4 mb-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-white font-bold text-lg">{selectedPair}</h3>
                <p className="text-gray-400 text-sm">{pairData.name}</p>
              </div>
              <div className="text-right">
                <p className="text-2xl font-bold text-white">{pairData.bid.toFixed(5)}</p>
                <div className={`flex items-center space-x-1 ${
                  pairData.change >= 0 ? 'text-green-400' : 'text-red-400'
                }`}>
                  {pairData.change >= 0 ? (
                    <TrendingUp className="h-4 w-4" />
                  ) : (
                    <TrendingDown className="h-4 w-4" />
                  )}
                  <span className="text-sm font-medium">
                    {pairData.changePercent >= 0 ? '+' : ''}{pairData.changePercent.toFixed(2)}%
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Chart */}
        <div className="bg-gray-800/30 backdrop-blur-sm rounded-2xl border border-gray-700/30 p-6 mb-6">
          <div className="bg-gray-900/50 rounded-xl p-4 h-64">
            <svg className="w-full h-full" viewBox="0 0 300 200">
              {/* Grid lines */}
              <defs>
                <pattern id="grid" width="30" height="20" patternUnits="userSpaceOnUse">
                  <path d="M 30 0 L 0 0 0 20" fill="none" stroke="#374151" strokeWidth="0.5" opacity="0.3"/>
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#grid)" />
              
              {/* Price levels */}
              {[0.25, 0.5, 0.75].map((level, i) => (
                <g key={i}>
                  <line
                    x1="0"
                    y1={20 + level * 160}
                    x2="300"
                    y2={20 + level * 160}
                    stroke="#6B7280"
                    strokeWidth="0.5"
                    strokeDasharray="2,2"
                  />
                  <text
                    x="5"
                    y={25 + level * 160}
                    fill="#9CA3AF"
                    fontSize="10"
                  >
                    {(maxPrice - (maxPrice - minPrice) * level).toFixed(5)}
                  </text>
                </g>
              ))}
              
              {/* Candlesticks */}
              {chartData.map((data, index) => renderCandlestick(data, index, maxPrice, minPrice))}
              
              {/* Open positions markers */}
              {pairTrades.map((trade, index) => {
                const entryY = 180 - ((trade.entryPrice! - minPrice) / (maxPrice - minPrice)) * 160;
                return (
                  <g key={trade.id}>
                    <line
                      x1="10"
                      y1={entryY}
                      x2="290"
                      y2={entryY}
                      stroke={trade.direction === 'buy' ? '#10B981' : '#EF4444'}
                      strokeWidth="2"
                      strokeDasharray="5,5"
                    />
                    <circle
                      cx="20"
                      cy={entryY}
                      r="4"
                      fill={trade.direction === 'buy' ? '#10B981' : '#EF4444'}
                    />
                    <text
                      x="30"
                      y={entryY + 4}
                      fill="white"
                      fontSize="10"
                      fontWeight="bold"
                    >
                      {trade.direction.toUpperCase()} {trade.volume}
                    </text>
                  </g>
                );
              })}
            </svg>
          </div>
        </div>

        {/* Open Positions on this pair */}
        {pairTrades.length > 0 && (
          <div className="bg-gray-800/30 backdrop-blur-sm rounded-2xl border border-gray-700/30 overflow-hidden">
            <div className="p-4 border-b border-gray-700/30">
              <h3 className="text-white font-semibold">Positions ouvertes sur {selectedPair}</h3>
            </div>
            
            <div className="divide-y divide-gray-700/30">
              {pairTrades.map((trade) => (
                <div key={trade.id} className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                        trade.direction === 'buy' ? 'bg-green-500/20' : 'bg-red-500/20'
                      }`}>
                        {trade.direction === 'buy' ? (
                          <TrendingUp className="h-5 w-5 text-green-400" />
                        ) : (
                          <TrendingDown className="h-5 w-5 text-red-400" />
                        )}
                      </div>
                      <div>
                        <h4 className="text-white font-semibold">
                          {trade.direction.toUpperCase()} {trade.volume}
                        </h4>
                        <p className="text-gray-400 text-sm">
                          Entrée: {trade.entryPrice?.toFixed(5)}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className={`font-bold ${
                        (trade.pnl || 0) >= 0 ? 'text-green-400' : 'text-red-400'
                      }`}>
                        {(trade.pnl || 0) >= 0 ? '+' : ''}${(trade.pnl || 0).toFixed(2)}
                      </p>
                      <p className="text-gray-400 text-sm">
                        {trade.currentPrice?.toFixed(5)}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Charts;