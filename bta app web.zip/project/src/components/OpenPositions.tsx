import React from 'react';
import { TrendingUp, TrendingDown, X, Clock } from 'lucide-react';
import { Trade } from '../types';
import { sendWebhook, webhookEndpoints } from '../utils/webhooks';

interface OpenPositionsProps {
  trades: Trade[];
  onCloseTrade: (tradeId: string) => void;
}

const OpenPositions: React.FC<OpenPositionsProps> = ({ trades, onCloseTrade }) => {
  const handleCloseTrade = async (tradeId: string) => {
    try {
      const trade = trades.find(t => t.id === tradeId);
      if (trade) {
        await sendWebhook(webhookEndpoints.closeTrade, {
          tradeId,
          pair: trade.pair,
          result: trade.pnl,
          timestamp: new Date().toISOString()
        });
      }
      onCloseTrade(tradeId);
    } catch (error) {
      console.error('Error closing trade:', error);
    }
  };

  const totalPnL = trades.reduce((sum, trade) => sum + (trade.pnl || 0), 0);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 pb-20">
      <div className="px-6 pt-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-bold text-white mb-2">Positions Ouvertes</h1>
            <p className="text-gray-400">{trades.length} position{trades.length !== 1 ? 's' : ''} active{trades.length !== 1 ? 's' : ''}</p>
          </div>
          <div className="w-12 h-12 bg-gradient-to-r from-pink-600 to-purple-600 rounded-2xl flex items-center justify-center">
            <Clock className="h-6 w-6 text-white" />
          </div>
        </div>

        {/* Total P&L */}
        <div className="bg-gray-800/30 backdrop-blur-sm rounded-2xl border border-gray-700/30 p-6 mb-6">
          <div className="text-center">
            <p className="text-gray-400 mb-2">P&L Total</p>
            <p className={`text-3xl font-bold ${totalPnL >= 0 ? 'text-green-400' : 'text-red-400'}`}>
              {totalPnL >= 0 ? '+' : ''}${totalPnL.toFixed(2)}
            </p>
          </div>
        </div>

        {/* Positions List */}
        {trades.length === 0 ? (
          <div className="bg-gray-800/30 backdrop-blur-sm rounded-2xl border border-gray-700/30 p-12 text-center">
            <Clock className="h-16 w-16 text-gray-600 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-white mb-2">Aucune position ouverte</h3>
            <p className="text-gray-400">Ouvrez votre première position pour commencer à trader</p>
          </div>
        ) : (
          <div className="space-y-4">
            {trades.map((trade) => (
              <div key={trade.id} className="bg-gray-800/30 backdrop-blur-sm rounded-2xl border border-gray-700/30 p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                      trade.direction === 'buy' ? 'bg-green-500/20' : 'bg-red-500/20'
                    }`}>
                      {trade.direction === 'buy' ? (
                        <TrendingUp className="h-6 w-6 text-green-400" />
                      ) : (
                        <TrendingDown className="h-6 w-6 text-red-400" />
                      )}
                    </div>
                    <div>
                      <h3 className="text-white font-bold text-lg">{trade.pair}</h3>
                      <p className="text-gray-400 text-sm">
                        {trade.direction.toUpperCase()} {trade.volume} lot{(trade.volume || 0) > 1 ? 's' : ''}
                      </p>
                    </div>
                  </div>
                  
                  <button
                    onClick={() => handleCloseTrade(trade.id)}
                    className="w-10 h-10 bg-red-500/20 hover:bg-red-500/30 rounded-xl flex items-center justify-center transition-colors"
                  >
                    <X className="h-5 w-5 text-red-400" />
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <p className="text-gray-400 text-sm">Prix d'entrée</p>
                    <p className="text-white font-mono font-semibold">{trade.entryPrice?.toFixed(5)}</p>
                  </div>
                  <div>
                    <p className="text-gray-400 text-sm">Prix actuel</p>
                    <p className="text-white font-mono font-semibold">{trade.currentPrice?.toFixed(5)}</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <p className="text-gray-400 text-sm">Stop Loss</p>
                    <p className="text-white font-mono">
                      {trade.stopLoss ? trade.stopLoss.toFixed(5) : 'Non défini'}
                    </p>
                  </div>
                  <div>
                    <p className="text-gray-400 text-sm">Take Profit</p>
                    <p className="text-white font-mono">
                      {trade.takeProfit ? trade.takeProfit.toFixed(5) : 'Non défini'}
                    </p>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-4 border-t border-gray-700/30">
                  <div>
                    <p className="text-gray-400 text-sm">Ouvert le</p>
                    <p className="text-white text-sm">
                      {trade.date.toLocaleDateString('fr-FR')} à {trade.date.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-gray-400 text-sm">P&L</p>
                    <p className={`text-xl font-bold ${
                      (trade.pnl || 0) >= 0 ? 'text-green-400' : 'text-red-400'
                    }`}>
                      {(trade.pnl || 0) >= 0 ? '+' : ''}${(trade.pnl || 0).toFixed(2)}
                    </p>
                  </div>
                </div>

                {trade.comment && (
                  <div className="mt-4 p-3 bg-gray-900/50 rounded-xl">
                    <p className="text-gray-400 text-sm mb-1">Commentaire</p>
                    <p className="text-white text-sm">{trade.comment}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default OpenPositions;