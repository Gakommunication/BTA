import React, { useState } from 'react';
import { TrendingUp, TrendingDown, Calendar, Filter, FileText, Star } from 'lucide-react';
import { Trade } from '../types';

interface TradeHistoryProps {
  trades: Trade[];
  onAnalyzeTrade: (trade: Trade) => void;
}

const TradeHistory: React.FC<TradeHistoryProps> = ({ trades, onAnalyzeTrade }) => {
  const [filter, setFilter] = useState<'all' | 'analyzed' | 'unanalyzed'>('all');
  
  const filteredTrades = trades.filter(trade => {
    if (filter === 'analyzed') return trade.analysis;
    if (filter === 'unanalyzed') return !trade.analysis;
    return true;
  });

  const totalResult = trades.reduce((sum, trade) => sum + (trade.result || 0), 0);
  const winningTrades = trades.filter(t => (t.result || 0) > 0);
  const losingTrades = trades.filter(t => (t.result || 0) < 0);
  const analyzedTrades = trades.filter(t => t.analysis);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 pb-20">
      <div className="px-6 pt-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-white mb-2">Historique</h1>
            <p className="text-gray-400">{trades.length} trade{trades.length !== 1 ? 's' : ''} fermé{trades.length !== 1 ? 's' : ''}</p>
          </div>
          <div className="w-12 h-12 bg-gradient-to-r from-pink-600 to-purple-600 rounded-2xl flex items-center justify-center">
            <FileText className="h-6 w-6 text-white" />
          </div>
        </div>

        {/* Filter Tabs */}
        <div className="flex space-x-2 mb-6">
          {[
            { id: 'all', label: 'Tous' },
            { id: 'analyzed', label: 'Analysés' },
            { id: 'unanalyzed', label: 'Non analysés' }
          ].map((filterOption) => (
            <button
              key={filterOption.id}
              onClick={() => setFilter(filterOption.id as any)}
              className={`px-4 py-2 rounded-xl text-sm font-medium transition-all duration-200 ${
                filter === filterOption.id
                  ? 'bg-pink-600 text-white'
                  : 'bg-gray-800/50 text-gray-400 hover:text-white hover:bg-gray-700/50'
              }`}
            >
              {filterOption.label}
            </button>
          ))}
        </div>

        {/* Stats Summary */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className="bg-gray-800/30 backdrop-blur-sm rounded-2xl border border-gray-700/30 p-4">
            <div className="text-center">
              <p className={`text-2xl font-bold ${totalResult >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                {totalResult >= 0 ? '+' : ''}${totalResult.toFixed(2)}
              </p>
              <p className="text-gray-400 text-sm">Résultat total</p>
            </div>
          </div>
          
          <div className="bg-gray-800/30 backdrop-blur-sm rounded-2xl border border-gray-700/30 p-4">
            <div className="text-center">
              <p className="text-2xl font-bold text-blue-400">{analyzedTrades.length}/{trades.length}</p>
              <p className="text-gray-400 text-sm">Trades analysés</p>
            </div>
          </div>
        </div>

        {/* Win/Loss Stats */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className="bg-green-500/10 border border-green-500/20 rounded-2xl p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-green-400 text-sm font-medium">Gains</span>
              <TrendingUp className="h-4 w-4 text-green-400" />
            </div>
            <p className="text-xl font-bold text-green-400">{winningTrades.length}</p>
            <p className="text-green-300 text-xs">
              {trades.length > 0 ? Math.round((winningTrades.length / trades.length) * 100) : 0}% de réussite
            </p>
          </div>

          <div className="bg-red-500/10 border border-red-500/20 rounded-2xl p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-red-400 text-sm font-medium">Pertes</span>
              <TrendingDown className="h-4 w-4 text-red-400" />
            </div>
            <p className="text-xl font-bold text-red-400">{losingTrades.length}</p>
            <p className="text-red-300 text-xs">
              {trades.length > 0 ? Math.round((losingTrades.length / trades.length) * 100) : 0}% d'échec
            </p>
          </div>
        </div>

        {/* Trades List */}
        {filteredTrades.length === 0 ? (
          <div className="bg-gray-800/30 backdrop-blur-sm rounded-2xl border border-gray-700/30 p-12 text-center">
            <FileText className="h-16 w-16 text-gray-600 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-white mb-2">
              {filter === 'all' ? 'Aucun trade' : 
               filter === 'analyzed' ? 'Aucun trade analysé' : 'Tous les trades sont analysés'}
            </h3>
            <p className="text-gray-400">
              {filter === 'unanalyzed' ? 'Parfait ! Continuez à analyser vos trades.' : 'Vos trades apparaîtront ici'}
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredTrades.map((trade) => (
              <div key={trade.id} className="bg-gray-800/30 backdrop-blur-sm rounded-2xl border border-gray-700/30 p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                      (trade.result || 0) >= 0 ? 'bg-green-500/20' : 'bg-red-500/20'
                    }`}>
                      {trade.direction === 'buy' ? (
                        <TrendingUp className={`h-6 w-6 ${(trade.result || 0) >= 0 ? 'text-green-400' : 'text-red-400'}`} />
                      ) : (
                        <TrendingDown className={`h-6 w-6 ${(trade.result || 0) >= 0 ? 'text-green-400' : 'text-red-400'}`} />
                      )}
                    </div>
                    <div>
                      <h3 className="text-white font-bold text-lg">{trade.pair}</h3>
                      <div className="flex items-center space-x-2 text-sm text-gray-400">
                        <Calendar className="h-3 w-3" />
                        <span>{trade.date.toLocaleDateString('fr-FR')}</span>
                        <span>•</span>
                        <span>{trade.direction.toUpperCase()} {trade.volume}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <p className={`text-xl font-bold ${
                      (trade.result || 0) >= 0 ? 'text-green-400' : 'text-red-400'
                    }`}>
                      {(trade.result || 0) >= 0 ? '+' : ''}${(trade.result || 0).toFixed(2)}
                    </p>
                    <p className="text-gray-400 text-sm">
                      Entrée: {trade.entryPrice?.toFixed(5)}
                    </p>
                  </div>
                </div>

                {trade.comment && (
                  <div className="mb-4 p-3 bg-gray-900/50 rounded-xl">
                    <p className="text-gray-400 text-sm mb-1">Commentaire</p>
                    <p className="text-white text-sm">{trade.comment}</p>
                  </div>
                )}

                {/* Analysis Display */}
                {trade.analysis ? (
                  <div className="mb-4 p-4 bg-blue-500/10 border border-blue-500/20 rounded-xl">
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="text-blue-400 font-semibold">Analyse du trade</h4>
                      <div className="flex items-center space-x-1">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`h-4 w-4 ${
                              i < trade.analysis!.rating ? 'text-yellow-400 fill-current' : 'text-gray-600'
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 mb-3">
                      <div>
                        <p className="text-gray-400 text-xs">État émotionnel</p>
                        <p className="text-white text-sm capitalize">{trade.analysis.emotionalState}</p>
                      </div>
                      <div>
                        <p className="text-gray-400 text-xs">Analysé le</p>
                        <p className="text-white text-sm">{trade.analysis.createdAt.toLocaleDateString('fr-FR')}</p>
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <div>
                        <p className="text-gray-400 text-xs">Raison</p>
                        <p className="text-white text-sm">{trade.analysis.reason}</p>
                      </div>
                      <div>
                        <p className="text-gray-400 text-xs">Leçon retenue</p>
                        <p className="text-white text-sm">{trade.analysis.lesson}</p>
                      </div>
                    </div>
                  </div>
                ) : (
                  <button
                    onClick={() => onAnalyzeTrade(trade)}
                    className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white py-3 px-6 rounded-xl font-medium transition-all duration-200 transform hover:scale-[1.02] active:scale-[0.98]"
                  >
                    Analyser ce trade
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default TradeHistory;