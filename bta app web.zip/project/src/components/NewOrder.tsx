import React, { useState } from 'react';
import { ArrowLeft, TrendingUp, TrendingDown, Send } from 'lucide-react';
import { ForexPair } from '../types';
import { sendWebhook, webhookEndpoints } from '../utils/webhooks';

interface NewOrderProps {
  selectedPair: string;
  forexPairs: ForexPair[];
  onBack: () => void;
  onOrderSubmitted: (order: any) => void;
}

const NewOrder: React.FC<NewOrderProps> = ({ 
  selectedPair, 
  forexPairs, 
  onBack, 
  onOrderSubmitted 
}) => {
  const [formData, setFormData] = useState({
    pair: selectedPair,
    orderType: 'market' as 'market' | 'limit' | 'stop',
    direction: 'buy' as 'buy' | 'sell',
    volume: '0.1',
    price: '',
    stopLoss: '',
    takeProfit: '',
    comment: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const pairData = forexPairs.find(p => p.symbol === formData.pair);
  const currentPrice = pairData ? (formData.direction === 'buy' ? pairData.ask : pairData.bid) : 0;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const orderData = {
        ...formData,
        volume: parseFloat(formData.volume),
        price: formData.price ? parseFloat(formData.price) : currentPrice,
        stopLoss: formData.stopLoss ? parseFloat(formData.stopLoss) : undefined,
        takeProfit: formData.takeProfit ? parseFloat(formData.takeProfit) : undefined,
        timestamp: new Date().toISOString()
      };

      await sendWebhook(webhookEndpoints.newTrade, orderData);
      
      onOrderSubmitted(orderData);
      onBack();
    } catch (error) {
      console.error('Error submitting order:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 pb-20">
      <div className="px-6 pt-8">
        {/* Header */}
        <div className="flex items-center mb-8">
          <button
            onClick={onBack}
            className="w-10 h-10 bg-gray-800/50 backdrop-blur-sm rounded-xl flex items-center justify-center border border-gray-700/50 mr-4 hover:bg-gray-700/50 transition-colors"
          >
            <ArrowLeft className="h-5 w-5 text-white" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-white">Nouvel Ordre</h1>
            <p className="text-gray-400">Ouvrir une position</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Pair Selection */}
          <div className="bg-gray-800/30 backdrop-blur-sm rounded-2xl p-6 border border-gray-700/30">
            <label className="block text-white font-semibold mb-4">Paire de devises</label>
            <select
              value={formData.pair}
              onChange={(e) => setFormData({ ...formData, pair: e.target.value })}
              className="w-full px-4 py-4 bg-gray-700/50 border-2 border-gray-600/30 rounded-xl text-white focus:border-pink-500/50 focus:outline-none transition-colors text-lg appearance-none"
            >
              {forexPairs.map((pair) => (
                <option key={pair.symbol} value={pair.symbol} className="bg-gray-800">
                  {pair.symbol} - {pair.name}
                </option>
              ))}
            </select>
            
            {pairData && (
              <div className="mt-4 p-4 bg-gray-900/50 rounded-xl">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Bid: <span className="text-white font-mono">{pairData.bid.toFixed(5)}</span></span>
                  <span className="text-gray-400">Ask: <span className="text-white font-mono">{pairData.ask.toFixed(5)}</span></span>
                  <span className="text-gray-400">Spread: <span className="text-white">{pairData.spread}</span></span>
                </div>
              </div>
            )}
          </div>

          {/* Order Type */}
          <div className="bg-gray-800/30 backdrop-blur-sm rounded-2xl p-6 border border-gray-700/30">
            <label className="block text-white font-semibold mb-4">Type d'ordre</label>
            <div className="grid grid-cols-3 gap-3">
              {(['market', 'limit', 'stop'] as const).map((type) => (
                <button
                  key={type}
                  type="button"
                  onClick={() => setFormData({ ...formData, orderType: type })}
                  className={`p-3 rounded-xl border-2 transition-all duration-200 ${
                    formData.orderType === type
                      ? 'border-pink-500 bg-pink-500/20 text-pink-400'
                      : 'border-gray-600/30 bg-gray-700/20 text-gray-300 hover:border-gray-500/50'
                  }`}
                >
                  {type.charAt(0).toUpperCase() + type.slice(1)}
                </button>
              ))}
            </div>
          </div>

          {/* Direction */}
          <div className="bg-gray-800/30 backdrop-blur-sm rounded-2xl p-6 border border-gray-700/30">
            <label className="block text-white font-semibold mb-4">Direction</label>
            <div className="grid grid-cols-2 gap-4">
              <button
                type="button"
                onClick={() => setFormData({ ...formData, direction: 'buy' })}
                className={`p-4 rounded-xl border-2 transition-all duration-200 flex items-center justify-center space-x-3 ${
                  formData.direction === 'buy'
                    ? 'border-green-500 bg-green-500/20 text-green-400 scale-105'
                    : 'border-gray-600/30 bg-gray-700/20 text-gray-300 hover:border-gray-500/50'
                }`}
              >
                <TrendingUp className="h-6 w-6" />
                <span className="font-semibold">BUY</span>
                {pairData && (
                  <span className="text-sm font-mono">{pairData.ask.toFixed(5)}</span>
                )}
              </button>
              <button
                type="button"
                onClick={() => setFormData({ ...formData, direction: 'sell' })}
                className={`p-4 rounded-xl border-2 transition-all duration-200 flex items-center justify-center space-x-3 ${
                  formData.direction === 'sell'
                    ? 'border-red-500 bg-red-500/20 text-red-400 scale-105'
                    : 'border-gray-600/30 bg-gray-700/20 text-gray-300 hover:border-gray-500/50'
                }`}
              >
                <TrendingDown className="h-6 w-6" />
                <span className="font-semibold">SELL</span>
                {pairData && (
                  <span className="text-sm font-mono">{pairData.bid.toFixed(5)}</span>
                )}
              </button>
            </div>
          </div>

          {/* Volume */}
          <div className="bg-gray-800/30 backdrop-blur-sm rounded-2xl p-6 border border-gray-700/30">
            <label className="block text-white font-semibold mb-4">Volume (Lots)</label>
            <input
              type="number"
              value={formData.volume}
              onChange={(e) => setFormData({ ...formData, volume: e.target.value })}
              placeholder="0.1"
              required
              min="0.01"
              step="0.01"
              className="w-full px-4 py-4 bg-transparent border-2 border-gray-600/30 rounded-xl text-white placeholder-gray-400 focus:border-pink-500/50 focus:outline-none transition-colors text-lg"
            />
            <div className="mt-2 flex space-x-2">
              {['0.01', '0.1', '0.5', '1.0'].map((vol) => (
                <button
                  key={vol}
                  type="button"
                  onClick={() => setFormData({ ...formData, volume: vol })}
                  className="px-3 py-1 bg-gray-700/50 rounded-lg text-gray-300 text-sm hover:bg-gray-600/50 transition-colors"
                >
                  {vol}
                </button>
              ))}
            </div>
          </div>

          {/* Price (for Limit/Stop orders) */}
          {formData.orderType !== 'market' && (
            <div className="bg-gray-800/30 backdrop-blur-sm rounded-2xl p-6 border border-gray-700/30">
              <label className="block text-white font-semibold mb-4">Prix</label>
              <input
                type="number"
                value={formData.price}
                onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                placeholder={currentPrice.toFixed(5)}
                required
                step="0.00001"
                className="w-full px-4 py-4 bg-transparent border-2 border-gray-600/30 rounded-xl text-white placeholder-gray-400 focus:border-pink-500/50 focus:outline-none transition-colors text-lg font-mono"
              />
            </div>
          )}

          {/* Stop Loss & Take Profit */}
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-gray-800/30 backdrop-blur-sm rounded-2xl p-6 border border-gray-700/30">
              <label className="block text-white font-semibold mb-4">Stop Loss</label>
              <input
                type="number"
                value={formData.stopLoss}
                onChange={(e) => setFormData({ ...formData, stopLoss: e.target.value })}
                placeholder="Optionnel"
                step="0.00001"
                className="w-full px-4 py-4 bg-transparent border-2 border-gray-600/30 rounded-xl text-white placeholder-gray-400 focus:border-pink-500/50 focus:outline-none transition-colors font-mono"
              />
            </div>
            
            <div className="bg-gray-800/30 backdrop-blur-sm rounded-2xl p-6 border border-gray-700/30">
              <label className="block text-white font-semibold mb-4">Take Profit</label>
              <input
                type="number"
                value={formData.takeProfit}
                onChange={(e) => setFormData({ ...formData, takeProfit: e.target.value })}
                placeholder="Optionnel"
                step="0.00001"
                className="w-full px-4 py-4 bg-transparent border-2 border-gray-600/30 rounded-xl text-white placeholder-gray-400 focus:border-pink-500/50 focus:outline-none transition-colors font-mono"
              />
            </div>
          </div>

          {/* Comment */}
          <div className="bg-gray-800/30 backdrop-blur-sm rounded-2xl p-6 border border-gray-700/30">
            <label className="block text-white font-semibold mb-4">Commentaire</label>
            <textarea
              value={formData.comment}
              onChange={(e) => setFormData({ ...formData, comment: e.target.value })}
              placeholder="Raison du trade, stratégie..."
              rows={3}
              className="w-full px-4 py-4 bg-transparent border-2 border-gray-600/30 rounded-xl text-white placeholder-gray-400 focus:border-pink-500/50 focus:outline-none transition-colors resize-none"
            />
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-700 hover:to-purple-700 disabled:opacity-50 disabled:cursor-not-allowed text-white py-4 px-6 rounded-2xl font-bold transition-all duration-200 flex items-center justify-center space-x-3 shadow-lg hover:shadow-xl transform hover:scale-[1.02] active:scale-[0.98]"
          >
            {isSubmitting ? (
              <>
                <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-white"></div>
                <span>Ouverture en cours...</span>
              </>
            ) : (
              <>
                <Send className="h-6 w-6" />
                <span>Ouvrir la position</span>
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};

export default NewOrder;