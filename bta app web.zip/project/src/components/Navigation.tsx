import React from 'react';
import { BarChart3, TrendingUp, MessageCircle, Clock, FileText, User, Plus } from 'lucide-react';

interface NavigationProps {
  currentPage: string;
  onPageChange: (page: string) => void;
}

const Navigation: React.FC<NavigationProps> = ({ currentPage, onPageChange }) => {
  const navItems = [
    { id: 'market', icon: BarChart3, label: 'Marché' },
    { id: 'charts', icon: TrendingUp, label: 'Graphiques' },
    { id: 'positions', icon: Clock, label: 'Positions' },
    { id: 'history', icon: FileText, label: 'Historique' },
    { id: 'assistant', icon: MessageCircle, label: 'Assistant' },
    { id: 'profile', icon: User, label: 'Profil' }
  ];

  return (
    <>
      {/* Top Navigation - Optimized for mobile */}
      <div className="fixed top-0 left-0 right-0 bg-gray-900/98 backdrop-blur-xl border-b border-gray-800/30 px-4 py-3 z-50 shadow-2xl">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-gradient-to-r from-pink-600 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
              <span className="text-white font-bold text-sm">B</span>
            </div>
            <div>
              <h1 className="text-lg font-bold text-white leading-none">BTA</h1>
              <p className="text-xs text-gray-400 leading-none">Trading Assistant</p>
            </div>
          </div>
          
          {/* Live indicator */}
          <div className="flex items-center space-x-2">
            <div className="flex items-center space-x-1">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
              <span className="text-xs text-green-400 font-medium">LIVE</span>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Navigation - Native mobile feel */}
      <div className="fixed bottom-0 left-0 right-0 z-50">
        {/* Backdrop blur effect */}
        <div className="absolute inset-0 bg-gray-900/95 backdrop-blur-xl border-t border-gray-800/30"></div>
        
        {/* Navigation content */}
        <div className="relative px-2 py-2">
          <div className="flex justify-center items-end max-w-sm mx-auto">
            {/* Left navigation items */}
            <div className="flex space-x-1">
              {navItems.slice(0, 2).map((item) => {
                const Icon = item.icon;
                const isActive = currentPage === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => onPageChange(item.id)}
                    className={`relative flex flex-col items-center justify-center p-2 rounded-2xl transition-all duration-300 transform ${
                      isActive
                        ? 'bg-pink-600/20 text-pink-400 scale-110 -translate-y-1'
                        : 'text-gray-500 hover:text-gray-300 hover:bg-gray-800/30 active:scale-95'
                    }`}
                  >
                    <div className={`p-2 rounded-xl transition-all duration-300 ${
                      isActive ? 'bg-pink-600/30' : ''
                    }`}>
                      <Icon className={`h-5 w-5 transition-all duration-300 ${
                        isActive ? 'scale-110' : ''
                      }`} />
                    </div>
                    <span className={`text-xs font-medium mt-1 transition-all duration-300 ${
                      isActive ? 'opacity-100' : 'opacity-70'
                    }`}>
                      {item.label}
                    </span>
                    
                    {/* Active indicator */}
                    {isActive && (
                      <div className="absolute -top-1 left-1/2 transform -translate-x-1/2 w-1 h-1 bg-pink-400 rounded-full"></div>
                    )}
                  </button>
                );
              })}
            </div>

            {/* Center New Order Button - Floating action button style */}
            <div className="mx-4 relative">
              <button
                onClick={() => onPageChange('new-order')}
                className={`relative w-16 h-16 rounded-2xl transition-all duration-300 transform shadow-2xl ${
                  currentPage === 'new-order'
                    ? 'bg-gradient-to-r from-pink-600 to-purple-600 scale-110 -translate-y-3 shadow-pink-500/30'
                    : 'bg-gradient-to-r from-pink-600 to-purple-600 hover:scale-105 hover:-translate-y-1 active:scale-95'
                }`}
                style={{
                  boxShadow: currentPage === 'new-order' 
                    ? '0 20px 40px rgba(236, 72, 153, 0.3), 0 0 0 4px rgba(236, 72, 153, 0.1)'
                    : '0 10px 30px rgba(0, 0, 0, 0.3)'
                }}
              >
                <div className="absolute inset-0 bg-white/10 rounded-2xl"></div>
                <div className="relative flex items-center justify-center h-full">
                  {currentPage === 'new-order' ? (
                    <TrendingUp className="h-7 w-7 text-white" />
                  ) : (
                    <Plus className="h-7 w-7 text-white" />
                  )}
                </div>
                
                {/* Ripple effect */}
                <div className="absolute inset-0 rounded-2xl bg-white/20 opacity-0 animate-ping"></div>
              </button>
              
              {/* Floating label */}
              <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                <div className="bg-gray-800 text-white text-xs px-2 py-1 rounded-lg whitespace-nowrap">
                  Nouvel Ordre
                </div>
              </div>
            </div>

            {/* Right navigation items */}
            <div className="flex space-x-1">
              {navItems.slice(2, 4).map((item) => {
                const Icon = item.icon;
                const isActive = currentPage === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => onPageChange(item.id)}
                    className={`relative flex flex-col items-center justify-center p-2 rounded-2xl transition-all duration-300 transform ${
                      isActive
                        ? 'bg-pink-600/20 text-pink-400 scale-110 -translate-y-1'
                        : 'text-gray-500 hover:text-gray-300 hover:bg-gray-800/30 active:scale-95'
                    }`}
                  >
                    <div className={`p-2 rounded-xl transition-all duration-300 ${
                      isActive ? 'bg-pink-600/30' : ''
                    }`}>
                      <Icon className={`h-5 w-5 transition-all duration-300 ${
                        isActive ? 'scale-110' : ''
                      }`} />
                    </div>
                    <span className={`text-xs font-medium mt-1 transition-all duration-300 ${
                      isActive ? 'opacity-100' : 'opacity-70'
                    }`}>
                      {item.label}
                    </span>
                    
                    {/* Active indicator */}
                    {isActive && (
                      <div className="absolute -top-1 left-1/2 transform -translate-x-1/2 w-1 h-1 bg-pink-400 rounded-full"></div>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Secondary navigation row for remaining items */}
          <div className="flex justify-center mt-2 space-x-8">
            {navItems.slice(4, 6).map((item) => {
              const Icon = item.icon;
              const isActive = currentPage === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onPageChange(item.id)}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-xl transition-all duration-300 transform ${
                    isActive
                      ? 'bg-pink-600/20 text-pink-400 scale-105'
                      : 'text-gray-500 hover:text-gray-300 hover:bg-gray-800/30 active:scale-95'
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  <span className="text-xs font-medium">{item.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Safe area for devices with home indicator */}
        <div className="h-safe-area-inset-bottom bg-gray-900/95"></div>
      </div>
    </>
  );
};

export default Navigation;