import React, { useState } from 'react';
import { Send, Bot, User, Sparkles } from 'lucide-react';
import { AIMessage } from '../types';
import { sendWebhook, webhookEndpoints } from '../utils/webhooks';

interface AssistantProps {
  messages: AIMessage[];
}

const Assistant: React.FC<AssistantProps> = ({ messages }) => {
  const [question, setQuestion] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [chatMessages, setChatMessages] = useState(messages);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!question.trim()) return;

    setIsLoading(true);

    // Add user message to chat
    const userMessage: AIMessage = {
      id: Date.now().toString(),
      content: question,
      timestamp: new Date(),
      type: 'general'
    };

    setChatMessages(prev => [userMessage, ...prev]);

    try {
      await sendWebhook(webhookEndpoints.aiQuestion, { question });
      
      // Simulate AI response
      setTimeout(() => {
        const aiResponse: AIMessage = {
          id: (Date.now() + 1).toString(),
          content: "C'est une excellente question ! En tant que votre assistant trading, je recommande de toujours analyser les tendances du marché et de respecter votre stratégie de money management. Avez-vous consulté les indicateurs techniques récents ?",
          timestamp: new Date(),
          type: 'general'
        };
        setChatMessages(prev => [aiResponse, ...prev]);
      }, 1500);

    } catch (error) {
      console.error('Error sending question:', error);
    } finally {
      setQuestion('');
      setIsLoading(false);
    }
  };

  const quickQuestions = [
    "Analyse du marché aujourd'hui",
    "Stratégie de money management",
    "Indicateurs techniques",
    "Gestion du risque"
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 pb-20">
      {/* Header */}
      <div className="px-6 pt-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-bold text-white mb-2">Assistant IA</h1>
            <p className="text-gray-400">Votre conseiller personnel</p>
          </div>
          <div className="w-12 h-12 bg-gradient-to-r from-pink-600 to-purple-600 rounded-2xl flex items-center justify-center">
            <Sparkles className="h-6 w-6 text-white" />
          </div>
        </div>

        {/* Quick Questions */}
        {chatMessages.length === 0 && (
          <div className="mb-6">
            <p className="text-gray-400 text-sm mb-4">Questions rapides :</p>
            <div className="grid grid-cols-2 gap-3">
              {quickQuestions.map((q, index) => (
                <button
                  key={index}
                  onClick={() => setQuestion(q)}
                  className="bg-gray-800/30 backdrop-blur-sm border border-gray-700/30 rounded-xl p-3 text-left text-white text-sm hover:bg-gray-700/30 transition-colors"
                >
                  {q}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Chat Container */}
        <div className="bg-gray-800/20 backdrop-blur-sm rounded-3xl border border-gray-700/30 h-[calc(100vh-320px)] flex flex-col">
          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {chatMessages.length === 0 ? (
              <div className="text-center py-12">
                <div className="w-16 h-16 bg-gradient-to-r from-pink-600 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Bot className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">Assistant IA prêt</h3>
                <p className="text-gray-400">Posez-moi vos questions sur le trading</p>
              </div>
            ) : (
              chatMessages.map((message, index) => {
                const isUser = index % 2 === 0 && chatMessages.length > messages.length;
                return (
                  <div
                    key={message.id}
                    className={`flex items-start space-x-3 ${isUser ? 'flex-row-reverse space-x-reverse' : ''}`}
                  >
                    <div className={`flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center ${
                      isUser ? 'bg-pink-600' : 'bg-gradient-to-r from-pink-600 to-purple-600'
                    }`}>
                      {isUser ? (
                        <User className="h-5 w-5 text-white" />
                      ) : (
                        <Bot className="h-5 w-5 text-white" />
                      )}
                    </div>
                    <div className={`flex-1 ${isUser ? 'text-right' : ''}`}>
                      <div className={`inline-block p-4 rounded-2xl max-w-xs ${
                        isUser
                          ? 'bg-pink-600 text-white'
                          : 'bg-gray-700/50 text-gray-200'
                      }`}>
                        <p className="text-sm leading-relaxed">{message.content}</p>
                      </div>
                      <p className="text-xs text-gray-500 mt-2">
                        {message.timestamp.toLocaleTimeString()}
                      </p>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Input */}
          <form onSubmit={handleSubmit} className="p-6 border-t border-gray-700/30">
            <div className="flex space-x-3">
              <input
                type="text"
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                placeholder="Posez votre question..."
                disabled={isLoading}
                className="flex-1 px-4 py-3 bg-gray-700/30 border border-gray-600/30 rounded-xl text-white placeholder-gray-400 focus:border-pink-500/50 focus:outline-none transition-colors disabled:opacity-50"
              />
              <button
                type="submit"
                disabled={isLoading || !question.trim()}
                className="bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-700 hover:to-purple-700 disabled:opacity-50 disabled:cursor-not-allowed text-white px-6 py-3 rounded-xl font-medium transition-all duration-200 flex items-center space-x-2 transform hover:scale-105 active:scale-95"
              >
                {isLoading ? (
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                ) : (
                  <Send className="h-5 w-5" />
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Assistant;