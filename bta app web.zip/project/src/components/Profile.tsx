import React, { useState } from 'react';
import { User, ChevronRight, Settings, Globe, Link, Bell, Shield, HelpCircle } from 'lucide-react';
import { UserProfile } from '../types';
import { tradingLevels, tradingStyles } from '../data/mockData';
import { sendWebhook, webhookEndpoints } from '../utils/webhooks';

interface ProfileProps {
  profile: UserProfile;
  onProfileUpdate: (profile: UserProfile) => void;
}

const Profile: React.FC<ProfileProps> = ({ profile, onProfileUpdate }) => {
  const [formData, setFormData] = useState(profile);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      await sendWebhook(webhookEndpoints.profileUpdate, formData);
      onProfileUpdate(formData);
    } catch (error) {
      console.error('Error updating profile:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const menuItems = [
    {
      icon: Settings,
      label: 'Type de tradeur',
      value: tradingStyles.find(s => s.value === formData.tradingStyle)?.label,
      color: 'green'
    },
    {
      icon: Link,
      label: 'Connexion compte trading',
      value: 'Non connecté',
      color: 'orange'
    },
    {
      icon: Globe,
      label: 'Langue',
      value: 'Français',
      color: 'blue'
    },
    {
      icon: Bell,
      label: 'Notifications',
      value: 'Activées',
      color: 'purple'
    },
    {
      icon: Shield,
      label: 'Sécurité',
      value: 'Configurée',
      color: 'red'
    },
    {
      icon: HelpCircle,
      label: 'Aide & Support',
      value: '',
      color: 'gray'
    }
  ];

  const colorClasses = {
    green: 'bg-green-600/20 text-green-400',
    orange: 'bg-orange-600/20 text-orange-400',
    blue: 'bg-blue-600/20 text-blue-400',
    purple: 'bg-purple-600/20 text-purple-400',
    red: 'bg-red-600/20 text-red-400',
    gray: 'bg-gray-600/20 text-gray-400'
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 pb-20">
      {/* Header */}
      <div className="px-6 pt-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-bold text-white mb-2">Mon compte</h1>
          </div>
        </div>

        {/* Profile Header */}
        <div className="bg-gradient-to-r from-pink-600 to-purple-600 rounded-3xl p-6 mb-8 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-16 translate-x-16"></div>
          <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/5 rounded-full translate-y-12 -translate-x-12"></div>
          
          <div className="relative z-10 flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center">
                <User className="h-8 w-8 text-white" />
              </div>
              <div>
                <h2 className="text-white text-xl font-bold">Prénom NOM</h2>
                <p className="text-purple-200">adresse@mail.com</p>
                <div className="flex items-center space-x-2 mt-2">
                  <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                  <span className="text-purple-200 text-sm">Compte vérifié</span>
                </div>
              </div>
            </div>
            <ChevronRight className="h-6 w-6 text-white/70" />
          </div>
        </div>

        {/* Settings Menu */}
        <div className="space-y-3">
          {menuItems.map((item, index) => {
            const Icon = item.icon;
            return (
              <div key={index} className="bg-gray-800/30 backdrop-blur-sm rounded-2xl border border-gray-700/30 overflow-hidden hover:bg-gray-700/30 transition-colors">
                <div className="p-4 flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${colorClasses[item.color as keyof typeof colorClasses]}`}>
                      <Icon className="h-5 w-5" />
                    </div>
                    <span className="text-white font-medium">{item.label}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    {item.value && (
                      <span className="text-gray-400 text-sm">{item.value}</span>
                    )}
                    <ChevronRight className="h-5 w-5 text-gray-400" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Stats Card */}
        <div className="mt-8 bg-gray-800/30 backdrop-blur-sm rounded-2xl border border-gray-700/30 p-6">
          <h3 className="text-white font-semibold mb-4">Statistiques du compte</h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center">
              <p className="text-2xl font-bold text-green-400">87%</p>
              <p className="text-gray-400 text-sm">Taux de réussite</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-blue-400">42</p>
              <p className="text-gray-400 text-sm">Trades totaux</p>
            </div>
          </div>
        </div>

        {/* Hidden Form for Functionality */}
        <form onSubmit={handleSubmit} className="hidden">
          <select
            value={formData.level}
            onChange={(e) => setFormData({ ...formData, level: e.target.value as any })}
          >
            {tradingLevels.map((level) => (
              <option key={level.value} value={level.value}>
                {level.label}
              </option>
            ))}
          </select>

          <input
            type="number"
            value={formData.dailyGoal}
            onChange={(e) => setFormData({ ...formData, dailyGoal: parseFloat(e.target.value) })}
          />

          <select
            value={formData.tradingStyle}
            onChange={(e) => setFormData({ ...formData, tradingStyle: e.target.value as any })}
          >
            {tradingStyles.map((style) => (
              <option key={style.value} value={style.value}>
                {style.label}
              </option>
            ))}
          </select>

          <button type="submit" disabled={isSubmitting}>
            Mettre à jour
          </button>
        </form>
      </div>
    </div>
  );
};

export default Profile;