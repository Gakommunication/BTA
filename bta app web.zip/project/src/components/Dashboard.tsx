import React from 'react';
import { TrendingUp, MessageCircle, Target, DollarSign } from 'lucide-react';
import { Trade, AIMessage } from '../types';

interface DashboardProps {
  trades: Trade[];
  aiMessages: AIMessage[];
  dailyGoal: number;
  onNewTrade: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ trades, aiMessages, dailyGoal, onNewTrade }) => {
  const lastTrade = trades[0];
  const dailyPnL = trades
    .filter(trade => {
      const today = new Date();
      const tradeDate = new Date(trade.date);
      return tradeDate.toDateString() === today.toDateString();
    })
    .reduce((sum, trade) => sum + (trade.result || 0), 0);

  const progress = Math.max(0, Math.min(100, (dailyPnL / dailyGoal) * 100));

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 pb-20">
      {/* Header */}
      <div className="px-6 pt-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Dashboard</h1>
          <p className="text-gray-400">Bienvenue sur BTA</p>
        </div>

        {/* Balance Card */}
        <div className="bg-gradient-to-r from-purple-600 to-pink-600 rounded-3xl p-6 mb-6 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-16 translate-x-16"></div>
          <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/5 rounded-full translate-y-12 -translate-x-12"></div>
          
          <div className="relative z-10">
            <div className="flex items-center justify-between mb-6">
              <div>
                <p className="text-purple-200 text-sm mb-1">Solde total</p>
                <h2 className="text-3xl font-bold text-white">€ 6,544.06</h2>
              </div>
              <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center">
                <DollarSign className="h-6 w-6 text-white" />
              </div>
            </div>

            {/* Progress Bar */}
            <div className="mb-4">
              <div className="flex justify-between text-sm text-purple-200 mb-2">
                <span>Objectif journalier</span>
                <span>{Math.round(progress)}%</span>
              </div>
              <div className="w-full bg-white/20 rounded-full h-2">
                <div 
                  className="bg-white rounded-full h-2 transition-all duration-500"
                  style={{ width: `${Math.min(progress, 100)}%` }}
                ></div>
              </div>
            </div>

            <div className="flex justify-between text-sm text-purple-200">
              <span>€{dailyPnL >= 0 ? '+' : ''}{dailyPnL}</span>
              <span>€{dailyGoal}</span>
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          {/* Last Trade */}
          <div className="bg-gray-800/50 backdrop-blur-sm rounded-2xl p-4 border border-gray-700/50">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-white font-semibold text-sm">Dernier Trade</h3>
              {lastTrade?.status === 'win' ? (
                <div className="w-8 h-8 bg-green-500/20 rounded-full flex items-center justify-center">
                  <TrendingUp className="h-4 w-4 text-green-400" />
                </div>
              ) : (
                <div className="w-8 h-8 bg-red-500/20 rounded-full flex items-center justify-center">
                  <TrendingUp className="h-4 w-4 text-red-400 rotate-180" />
                </div>
              )}
            </div>
            
            {lastTrade ? (
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-400 text-xs">Paire</span>
                  <span className="text-white text-xs font-medium">{lastTrade.pair}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400 text-xs">Résultat</span>
                  <span className={`text-xs font-semibold ${
                    lastTrade.result && lastTrade.result > 0 ? 'text-green-400' : 'text-red-400'
                  }`}>
                    {lastTrade.result ? `€${lastTrade.result}` : 'En cours'}
                  </span>
                </div>
              </div>
            ) : (
              <p className="text-gray-400 text-xs">Aucun trade</p>
            )}
          </div>

          {/* AI Message */}
          <div className="bg-gray-800/50 backdrop-blur-sm rounded-2xl p-4 border border-gray-700/50">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-white font-semibold text-sm">Message IA</h3>
              <div className="w-8 h-8 bg-blue-500/20 rounded-full flex items-center justify-center">
                <MessageCircle className="h-4 w-4 text-blue-400" />
              </div>
            </div>
            
            {aiMessages[0] ? (
              <div>
                <p className="text-gray-300 text-xs leading-relaxed line-clamp-3">
                  {aiMessages[0].content}
                </p>
                <span className="text-xs text-gray-500 mt-2 block">
                  {aiMessages[0].timestamp.toLocaleTimeString()}
                </span>
              </div>
            ) : (
              <p className="text-gray-400 text-xs">Aucun message</p>
            )}
          </div>
        </div>

        {/* Performance Cards */}
        <div className="grid grid-cols-2 gap-4 mb-8">
          <div className="bg-green-500/10 border border-green-500/20 rounded-2xl p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-green-400 text-sm font-medium">Gains</span>
              <TrendingUp className="h-4 w-4 text-green-400" />
            </div>
            <p className="text-2xl font-bold text-green-400">€2,272</p>
            <p className="text-green-300 text-xs">+15.2%</p>
          </div>

          <div className="bg-red-500/10 border border-red-500/20 rounded-2xl p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-red-400 text-sm font-medium">Pertes</span>
              <TrendingUp className="h-4 w-4 text-red-400 rotate-180" />
            </div>
            <p className="text-2xl font-bold text-red-400">€544</p>
            <p className="text-red-300 text-xs">-8.1%</p>
          </div>
        </div>

        {/* New Trade Button */}
        <button
          onClick={onNewTrade}
          className="w-full bg-white rounded-2xl py-4 px-6 flex items-center justify-center space-x-3 shadow-lg hover:shadow-xl transition-all duration-200 transform hover:scale-[1.02] active:scale-[0.98]"
        >
          <span className="text-gray-900 font-bold text-lg">Nouveau trade</span>
          <div className="w-8 h-8 bg-pink-600 rounded-full flex items-center justify-center">
            <TrendingUp className="h-4 w-4 text-white" />
          </div>
        </button>
      </div>
    </div>
  );
};

export default Dashboard;