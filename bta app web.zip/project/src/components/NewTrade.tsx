import React, { useState } from 'react';
import { ArrowLeft, DollarSign, TrendingUp, TrendingDown, Send } from 'lucide-react';
import { currencyPairs } from '../data/mockData';
import { sendWebhook, webhookEndpoints } from '../utils/webhooks';

interface NewTradeProps {
  onBack: () => void;
  onTradeSubmitted: (trade: any) => void;
}

const NewTrade: React.FC<NewTradeProps> = ({ onBack, onTradeSubmitted }) => {
  const [formData, setFormData] = useState({
    amount: '',
    pair: 'EUR/USD',
    direction: 'buy' as 'buy' | 'sell',
    reason: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const tradeData = {
        ...formData,
        amount: parseFloat(formData.amount),
        timestamp: new Date().toISOString()
      };

      await sendWebhook(webhookEndpoints.newTrade, tradeData);
      
      onTradeSubmitted(tradeData);
      onBack();
    } catch (error) {
      console.error('Error submitting trade:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 pb-20">
      <div className="px-6 pt-8">
        {/* Header */}
        <div className="flex items-center mb-8">
          <button
            onClick={onBack}
            className="w-10 h-10 bg-gray-800/50 backdrop-blur-sm rounded-xl flex items-center justify-center border border-gray-700/50 mr-4 hover:bg-gray-700/50 transition-colors"
          >
            <ArrowLeft className="h-5 w-5 text-white" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-white">Nouveau Trade</h1>
            <p className="text-gray-400">Prise de position</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Amount */}
          <div className="bg-gray-800/30 backdrop-blur-sm rounded-2xl p-6 border border-gray-700/30">
            <label className="block text-white font-semibold mb-4">Montant</label>
            <div className="relative">
              <div className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400">
                <DollarSign className="h-5 w-5" />
              </div>
              <input
                type="number"
                value={formData.amount}
                onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                placeholder="1000"
                required
                min="1"
                step="0.01"
                className="w-full pl-12 pr-4 py-4 bg-transparent border-2 border-gray-600/30 rounded-xl text-white placeholder-gray-400 focus:border-pink-500/50 focus:outline-none transition-colors text-lg"
              />
            </div>
          </div>

          {/* Currency Pair */}
          <div className="bg-gray-800/30 backdrop-blur-sm rounded-2xl p-6 border border-gray-700/30">
            <label className="block text-white font-semibold mb-4">Paire de devises</label>
            <select
              value={formData.pair}
              onChange={(e) => setFormData({ ...formData, pair: e.target.value })}
              className="w-full px-4 py-4 bg-gray-700/50 border-2 border-gray-600/30 rounded-xl text-white focus:border-pink-500/50 focus:outline-none transition-colors text-lg appearance-none"
            >
              {currencyPairs.map((pair) => (
                <option key={pair} value={pair} className="bg-gray-800">{pair}</option>
              ))}
            </select>
          </div>

          {/* Direction */}
          <div className="bg-gray-800/30 backdrop-blur-sm rounded-2xl p-6 border border-gray-700/30">
            <label className="block text-white font-semibold mb-4">Sens de la position</label>
            <div className="grid grid-cols-2 gap-4">
              <button
                type="button"
                onClick={() => setFormData({ ...formData, direction: 'buy' })}
                className={`p-4 rounded-xl border-2 transition-all duration-200 flex items-center justify-center space-x-3 ${
                  formData.direction === 'buy'
                    ? 'border-green-500 bg-green-500/20 text-green-400 scale-105'
                    : 'border-gray-600/30 bg-gray-700/20 text-gray-300 hover:border-gray-500/50'
                }`}
              >
                <TrendingUp className="h-6 w-6" />
                <span className="font-semibold">Buy</span>
              </button>
              <button
                type="button"
                onClick={() => setFormData({ ...formData, direction: 'sell' })}
                className={`p-4 rounded-xl border-2 transition-all duration-200 flex items-center justify-center space-x-3 ${
                  formData.direction === 'sell'
                    ? 'border-red-500 bg-red-500/20 text-red-400 scale-105'
                    : 'border-gray-600/30 bg-gray-700/20 text-gray-300 hover:border-gray-500/50'
                }`}
              >
                <TrendingDown className="h-6 w-6" />
                <span className="font-semibold">Sell</span>
              </button>
            </div>
          </div>

          {/* Reason */}
          <div className="bg-gray-800/30 backdrop-blur-sm rounded-2xl p-6 border border-gray-700/30">
            <label className="block text-white font-semibold mb-4">Raison du trade</label>
            <textarea
              value={formData.reason}
              onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
              placeholder="Décrivez votre analyse technique, fondamentale ou votre stratégie..."
              required
              rows={4}
              className="w-full px-4 py-4 bg-transparent border-2 border-gray-600/30 rounded-xl text-white placeholder-gray-400 focus:border-pink-500/50 focus:outline-none transition-colors resize-none"
            />
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-700 hover:to-purple-700 disabled:opacity-50 disabled:cursor-not-allowed text-white py-4 px-6 rounded-2xl font-bold transition-all duration-200 flex items-center justify-center space-x-3 shadow-lg hover:shadow-xl transform hover:scale-[1.02] active:scale-[0.98]"
          >
            {isSubmitting ? (
              <>
                <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-white"></div>
                <span>Envoi en cours...</span>
              </>
            ) : (
              <>
                <Send className="h-6 w-6" />
                <span>Confirmer le trade</span>
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};

export default NewTrade;