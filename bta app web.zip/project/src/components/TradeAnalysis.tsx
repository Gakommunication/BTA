import React, { useState } from 'react';
import { X, Star, Upload, FileText, Image, Mic } from 'lucide-react';
import { Trade, TradeAnalysis as TradeAnalysisType } from '../types';
import { emotionalStates } from '../data/mockData';
import { sendWebhook, webhookEndpoints } from '../utils/webhooks';

interface TradeAnalysisProps {
  trade: Trade;
  onClose: () => void;
  onSubmit: (analysis: TradeAnalysisType) => void;
}

const TradeAnalysis: React.FC<TradeAnalysisProps> = ({ trade, onClose, onSubmit }) => {
  const [formData, setFormData] = useState({
    rating: 0,
    emotionalState: 'calm' as 'calm' | 'stressed' | 'euphoric' | 'frustrated',
    reason: '',
    lesson: ''
  });
  const [attachments, setAttachments] = useState<File[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    setAttachments(prev => [...prev, ...files]);
  };

  const removeAttachment = (index: number) => {
    setAttachments(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.rating === 0) return;

    setIsSubmitting(true);

    try {
      const analysis: TradeAnalysisType = {
        id: Date.now().toString(),
        tradeId: trade.id,
        rating: formData.rating,
        emotionalState: formData.emotionalState,
        reason: formData.reason,
        lesson: formData.lesson,
        attachments: attachments.map((file, index) => ({
          id: `${Date.now()}-${index}`,
          type: file.type.startsWith('image/') ? 'image' : 
                file.type.startsWith('audio/') ? 'audio' : 'document',
          name: file.name,
          url: URL.createObjectURL(file),
          size: file.size
        })),
        createdAt: new Date()
      };

      await sendWebhook(webhookEndpoints.tradeAnalysis, {
        tradeId: trade.id,
        analysis,
        timestamp: new Date().toISOString()
      });

      onSubmit(analysis);
    } catch (error) {
      console.error('Error submitting analysis:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const getFileIcon = (file: File) => {
    if (file.type.startsWith('image/')) return <Image className="h-4 w-4" />;
    if (file.type.startsWith('audio/')) return <Mic className="h-4 w-4" />;
    return <FileText className="h-4 w-4" />;
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-gray-800 rounded-3xl border border-gray-700 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-700">
          <div>
            <h2 className="text-xl font-bold text-white">Analyser le trade</h2>
            <p className="text-gray-400 text-sm">
              {trade.pair} • {trade.direction.toUpperCase()} • 
              {(trade.result || 0) >= 0 ? '+' : ''}${(trade.result || 0).toFixed(2)}
            </p>
          </div>
          <button
            onClick={onClose}
            className="w-10 h-10 bg-gray-700 hover:bg-gray-600 rounded-xl flex items-center justify-center transition-colors"
          >
            <X className="h-5 w-5 text-white" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Rating */}
          <div>
            <label className="block text-white font-semibold mb-4">Note du trade (1-5 étoiles)</label>
            <div className="flex space-x-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  type="button"
                  onClick={() => setFormData({ ...formData, rating: star })}
                  className="transition-colors"
                >
                  <Star
                    className={`h-8 w-8 ${
                      star <= formData.rating
                        ? 'text-yellow-400 fill-current'
                        : 'text-gray-600 hover:text-gray-400'
                    }`}
                  />
                </button>
              ))}
            </div>
          </div>

          {/* Emotional State */}
          <div>
            <label className="block text-white font-semibold mb-4">État émotionnel</label>
            <div className="grid grid-cols-2 gap-3">
              {emotionalStates.map((state) => (
                <button
                  key={state.value}
                  type="button"
                  onClick={() => setFormData({ ...formData, emotionalState: state.value })}
                  className={`p-3 rounded-xl border-2 transition-all duration-200 text-left ${
                    formData.emotionalState === state.value
                      ? `border-${state.color}-500 bg-${state.color}-500/20 text-${state.color}-400`
                      : 'border-gray-600/30 bg-gray-700/20 text-gray-300 hover:border-gray-500/50'
                  }`}
                >
                  {state.label}
                </button>
              ))}
            </div>
          </div>

          {/* Reason */}
          <div>
            <label className="block text-white font-semibold mb-4">Pourquoi j'ai pris ce trade</label>
            <textarea
              value={formData.reason}
              onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
              placeholder="Décrivez votre analyse, les signaux qui vous ont poussé à prendre cette position..."
              required
              rows={3}
              className="w-full px-4 py-3 bg-gray-700/50 border border-gray-600/30 rounded-xl text-white placeholder-gray-400 focus:border-pink-500/50 focus:outline-none transition-colors resize-none"
            />
          </div>

          {/* Lesson */}
          <div>
            <label className="block text-white font-semibold mb-4">Leçon retenue</label>
            <textarea
              value={formData.lesson}
              onChange={(e) => setFormData({ ...formData, lesson: e.target.value })}
              placeholder="Qu'avez-vous appris de ce trade ? Que feriez-vous différemment ?"
              required
              rows={4}
              className="w-full px-4 py-3 bg-gray-700/50 border border-gray-600/30 rounded-xl text-white placeholder-gray-400 focus:border-pink-500/50 focus:outline-none transition-colors resize-none"
            />
          </div>

          {/* File Attachments */}
          <div>
            <label className="block text-white font-semibold mb-4">Pièces jointes</label>
            
            <div className="border-2 border-dashed border-gray-600/30 rounded-xl p-6 text-center hover:border-gray-500/50 transition-colors">
              <input
                type="file"
                multiple
                accept="image/*,audio/*,.pdf,.doc,.docx"
                onChange={handleFileUpload}
                className="hidden"
                id="file-upload"
              />
              <label htmlFor="file-upload" className="cursor-pointer">
                <Upload className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                <p className="text-gray-400 text-sm">
                  Cliquez pour ajouter des fichiers
                </p>
                <p className="text-gray-500 text-xs mt-1">
                  Images, audio, PDF, documents
                </p>
              </label>
            </div>

            {/* Attachment List */}
            {attachments.length > 0 && (
              <div className="mt-4 space-y-2">
                {attachments.map((file, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-700/30 rounded-xl">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-gray-600 rounded-lg flex items-center justify-center">
                        {getFileIcon(file)}
                      </div>
                      <div>
                        <p className="text-white text-sm font-medium">{file.name}</p>
                        <p className="text-gray-400 text-xs">
                          {(file.size / 1024 / 1024).toFixed(2)} MB
                        </p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => removeAttachment(index)}
                      className="w-6 h-6 bg-red-500/20 hover:bg-red-500/30 rounded-lg flex items-center justify-center transition-colors"
                    >
                      <X className="h-3 w-3 text-red-400" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isSubmitting || formData.rating === 0}
            className="w-full bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-700 hover:to-purple-700 disabled:opacity-50 disabled:cursor-not-allowed text-white py-4 px-6 rounded-2xl font-bold transition-all duration-200 flex items-center justify-center space-x-3"
          >
            {isSubmitting ? (
              <>
                <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-white"></div>
                <span>Enregistrement...</span>
              </>
            ) : (
              <span>Enregistrer l'analyse</span>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};

export default TradeAnalysis;