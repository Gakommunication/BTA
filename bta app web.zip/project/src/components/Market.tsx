import React from 'react';
import { TrendingUp, TrendingDown, DollarSign, Activity, BarChart3, Wifi, WifiOff, AlertTriangle } from 'lucide-react';
import { ForexPair, AccountInfo } from '../types';

interface MarketProps {
  forexPairs: ForexPair[];
  accountInfo: AccountInfo;
  selectedPair: string;
  onSelectPair: (pair: string) => void;
  onNewOrder: () => void;
  apiStatus?: 'connecting' | 'connected' | 'error' | 'fallback';
}

const Market: React.FC<MarketProps> = ({ 
  forexPairs, 
  accountInfo, 
  selectedPair, 
  onSelectPair, 
  onNewOrder,
  apiStatus = 'fallback'
}) => {
  const selectedPairData = forexPairs.find(p => p.symbol === selectedPair);

  const getStatusIcon = () => {
    switch (apiStatus) {
      case 'connected':
        return <Wifi className="h-4 w-4 text-green-400" />;
      case 'connecting':
        return <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-400"></div>;
      case 'error':
        return <WifiOff className="h-4 w-4 text-red-400" />;
      case 'fallback':
        return <AlertTriangle className="h-4 w-4 text-yellow-400" />;
      default:
        return <WifiOff className="h-4 w-4 text-gray-400" />;
    }
  };

  const getStatusText = () => {
    switch (apiStatus) {
      case 'connected':
        return 'Données en temps réel';
      case 'connecting':
        return 'Connexion...';
      case 'error':
        return 'Erreur de connexion';
      case 'fallback':
        return 'Données simulées';
      default:
        return 'Hors ligne';
    }
  };

  const getStatusColor = () => {
    switch (apiStatus) {
      case 'connected':
        return 'text-green-400';
      case 'connecting':
        return 'text-blue-400';
      case 'error':
        return 'text-red-400';
      case 'fallback':
        return 'text-yellow-400';
      default:
        return 'text-gray-400';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 pb-20">
      <div className="px-6 pt-8">
        {/* Header with API Status */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <h1 className="text-3xl font-bold text-white">Marché Forex</h1>
            <div className="flex items-center space-x-2">
              {getStatusIcon()}
              <span className={`text-sm font-medium ${getStatusColor()}`}>
                {getStatusText()}
              </span>
            </div>
          </div>
          <p className="text-gray-400">Trading en temps réel</p>
        </div>

        {/* API Status Banner */}
        {apiStatus === 'fallback' && (
          <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-2xl p-4 mb-6">
            <div className="flex items-center space-x-3">
              <AlertTriangle className="h-5 w-5 text-yellow-400" />
              <div>
                <p className="text-yellow-400 font-medium text-sm">Mode simulation</p>
                <p className="text-yellow-300 text-xs">
                  Les données affichées sont simulées. Pour des données réelles, configurez une clé API.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Account Info */}
        <div className="bg-gradient-to-r from-purple-600 to-pink-600 rounded-3xl p-6 mb-6 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-16 translate-x-16"></div>
          <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/5 rounded-full translate-y-12 -translate-x-12"></div>
          
          <div className="relative z-10">
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-purple-200 text-sm mb-1">Solde</p>
                <h2 className="text-2xl font-bold text-white">${accountInfo.balance.toFixed(2)}</h2>
              </div>
              <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center">
                <DollarSign className="h-6 w-6 text-white" />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <p className="text-purple-200 text-xs">Équité</p>
                <p className="text-white font-semibold">${accountInfo.equity.toFixed(2)}</p>
              </div>
              <div>
                <p className="text-purple-200 text-xs">Marge</p>
                <p className="text-white font-semibold">${accountInfo.margin.toFixed(2)}</p>
              </div>
              <div>
                <p className="text-purple-200 text-xs">Niveau</p>
                <p className="text-white font-semibold">{accountInfo.marginLevel.toFixed(1)}%</p>
              </div>
            </div>
          </div>
        </div>

        {/* Selected Pair Chart */}
        {selectedPairData && (
          <div className="bg-gray-800/30 backdrop-blur-sm rounded-2xl border border-gray-700/30 p-6 mb-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-white font-bold text-lg">{selectedPairData.symbol}</h3>
                <p className="text-gray-400 text-sm">{selectedPairData.name}</p>
              </div>
              <div className="text-right">
                <p className="text-2xl font-bold text-white">{selectedPairData.bid.toFixed(5)}</p>
                <div className={`flex items-center space-x-1 ${
                  selectedPairData.change >= 0 ? 'text-green-400' : 'text-red-400'
                }`}>
                  {selectedPairData.change >= 0 ? (
                    <TrendingUp className="h-4 w-4" />
                  ) : (
                    <TrendingDown className="h-4 w-4" />
                  )}
                  <span className="text-sm font-medium">
                    {selectedPairData.changePercent >= 0 ? '+' : ''}{selectedPairData.changePercent.toFixed(2)}%
                  </span>
                </div>
              </div>
            </div>

            {/* Mini Chart */}
            <div className="h-32 bg-gray-900/50 rounded-xl mb-4 flex items-center justify-center">
              <div className="w-full h-full p-4">
                <svg className="w-full h-full" viewBox="0 0 300 100">
                  <path
                    d={`M0,${selectedPairData.change >= 0 ? '80' : '20'} Q75,${selectedPairData.change >= 0 ? '60' : '40'} 150,${selectedPairData.change >= 0 ? '40' : '60'} T300,${selectedPairData.change >= 0 ? '20' : '80'}`}
                    stroke={selectedPairData.change >= 0 ? '#10B981' : '#EF4444'}
                    strokeWidth="2"
                    fill="none"
                  />
                  <defs>
                    <linearGradient id="gradient" x1="0%" y1="0%" x2="0%" y2="100%">
                      <stop offset="0%" stopColor={selectedPairData.change >= 0 ? '#10B981' : '#EF4444'} stopOpacity="0.3"/>
                      <stop offset="100%" stopColor={selectedPairData.change >= 0 ? '#10B981' : '#EF4444'} stopOpacity="0"/>
                    </linearGradient>
                  </defs>
                  <path
                    d={`M0,${selectedPairData.change >= 0 ? '80' : '20'} Q75,${selectedPairData.change >= 0 ? '60' : '40'} 150,${selectedPairData.change >= 0 ? '40' : '60'} T300,${selectedPairData.change >= 0 ? '20' : '80'} L300,100 L0,100 Z`}
                    fill="url(#gradient)"
                  />
                </svg>
              </div>
            </div>

            <div className="flex justify-between text-sm text-gray-400 mb-4">
              <span>H: {selectedPairData.high.toFixed(5)}</span>
              <span>L: {selectedPairData.low.toFixed(5)}</span>
              <span>Spread: {selectedPairData.spread}</span>
            </div>

            <button
              onClick={onNewOrder}
              className="w-full bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-700 hover:to-purple-700 text-white py-3 px-6 rounded-xl font-bold transition-all duration-200 transform hover:scale-[1.02] active:scale-[0.98]"
            >
              Nouvel Ordre
            </button>
          </div>
        )}

        {/* Forex Pairs List */}
        <div className="bg-gray-800/30 backdrop-blur-sm rounded-2xl border border-gray-700/30 overflow-hidden">
          <div className="p-4 border-b border-gray-700/30">
            <h3 className="text-white font-semibold flex items-center space-x-2">
              <Activity className="h-5 w-5" />
              <span>Paires Forex</span>
            </h3>
          </div>
          
          <div className="divide-y divide-gray-700/30">
            {forexPairs.map((pair) => (
              <div 
                key={pair.symbol} 
                className={`p-4 hover:bg-gray-700/20 transition-colors cursor-pointer ${
                  selectedPair === pair.symbol ? 'bg-purple-600/20 border-l-4 border-purple-500' : ''
                }`}
                onClick={() => onSelectPair(pair.symbol)}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl flex items-center justify-center">
                      <BarChart3 className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <h4 className="text-white font-semibold">{pair.symbol}</h4>
                      <p className="text-gray-400 text-sm">{pair.name}</p>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <div className="flex space-x-4 mb-1">
                      <div>
                        <p className="text-xs text-gray-400">Bid</p>
                        <p className="text-white font-mono text-sm">{pair.bid.toFixed(5)}</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-400">Ask</p>
                        <p className="text-white font-mono text-sm">{pair.ask.toFixed(5)}</p>
                      </div>
                    </div>
                    <div className={`flex items-center justify-end space-x-1 ${
                      pair.change >= 0 ? 'text-green-400' : 'text-red-400'
                    }`}>
                      {pair.change >= 0 ? (
                        <TrendingUp className="h-3 w-3" />
                      ) : (
                        <TrendingDown className="h-3 w-3" />
                      )}
                      <span className="text-xs font-medium">
                        {pair.changePercent >= 0 ? '+' : ''}{pair.changePercent.toFixed(2)}%
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Market;