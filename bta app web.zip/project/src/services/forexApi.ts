import axios from 'axios';
import { ForexPair } from '../types';

// Configuration for different API providers
const API_CONFIG = {
  // Free tier from Alpha Vantage (5 API calls per minute, 500 per day)
  ALPHA_VANTAGE: {
    baseUrl: 'https://www.alphavantage.co/query',
    apiKey: 'demo', // Replace with your actual API key
    rateLimit: 12000 // 12 seconds between calls for free tier
  },
  
  // Free tier from Twelve Data (800 API calls per day)
  TWELVE_DATA: {
    baseUrl: 'https://api.twelvedata.com',
    apiKey: 'demo', // Replace with your actual API key
    rateLimit: 1000 // 1 second between calls
  },
  
  // Fallback to Exchange Rates API (free, no key required)
  EXCHANGE_RATES: {
    baseUrl: 'https://api.exchangerate-api.com/v4/latest',
    rateLimit: 1000
  }
};

// Current provider - change this to switch APIs
const CURRENT_PROVIDER = 'EXCHANGE_RATES';

let lastApiCall = 0;

// Rate limiting helper
const rateLimitDelay = async () => {
  const now = Date.now();
  const timeSinceLastCall = now - lastApiCall;
  const minDelay = API_CONFIG[CURRENT_PROVIDER as keyof typeof API_CONFIG].rateLimit;
  
  if (timeSinceLastCall < minDelay) {
    await new Promise(resolve => setTimeout(resolve, minDelay - timeSinceLastCall));
  }
  
  lastApiCall = Date.now();
};

// Convert currency pair format (EURUSD -> EUR/USD)
const formatPairForApi = (pair: string): { base: string; quote: string } => {
  const base = pair.substring(0, 3);
  const quote = pair.substring(3, 6);
  return { base, quote };
};

// Alpha Vantage API implementation
const fetchFromAlphaVantage = async (pairs: string[]): Promise<Partial<ForexPair>[]> => {
  const results: Partial<ForexPair>[] = [];
  
  for (const pair of pairs) {
    try {
      await rateLimitDelay();
      
      const { base, quote } = formatPairForApi(pair);
      const response = await axios.get(API_CONFIG.ALPHA_VANTAGE.baseUrl, {
        params: {
          function: 'CURRENCY_EXCHANGE_RATE',
          from_currency: base,
          to_currency: quote,
          apikey: API_CONFIG.ALPHA_VANTAGE.apiKey
        },
        timeout: 10000
      });

      const data = response.data['Realtime Currency Exchange Rate'];
      if (data) {
        const currentRate = parseFloat(data['5. Exchange Rate']);
        const previousRate = parseFloat(data['8. Previous Close']) || currentRate;
        const change = currentRate - previousRate;
        const changePercent = (change / previousRate) * 100;

        results.push({
          symbol: pair,
          bid: currentRate - 0.0001, // Simulate bid/ask spread
          ask: currentRate + 0.0001,
          spread: 0.2,
          change,
          changePercent,
          high: currentRate * 1.002,
          low: currentRate * 0.998
        });
      }
    } catch (error) {
      console.error(`Error fetching ${pair} from Alpha Vantage:`, error);
    }
  }
  
  return results;
};

// Twelve Data API implementation
const fetchFromTwelveData = async (pairs: string[]): Promise<Partial<ForexPair>[]> => {
  const results: Partial<ForexPair>[] = [];
  
  for (const pair of pairs) {
    try {
      await rateLimitDelay();
      
      const { base, quote } = formatPairForApi(pair);
      const symbol = `${base}/${quote}`;
      
      const response = await axios.get(`${API_CONFIG.TWELVE_DATA.baseUrl}/price`, {
        params: {
          symbol,
          apikey: API_CONFIG.TWELVE_DATA.apiKey
        },
        timeout: 10000
      });

      if (response.data && response.data.price) {
        const currentRate = parseFloat(response.data.price);
        
        results.push({
          symbol: pair,
          bid: currentRate - 0.0001,
          ask: currentRate + 0.0001,
          spread: 0.2,
          change: (Math.random() - 0.5) * 0.01, // Simulated change
          changePercent: (Math.random() - 0.5) * 2,
          high: currentRate * 1.002,
          low: currentRate * 0.998
        });
      }
    } catch (error) {
      console.error(`Error fetching ${pair} from Twelve Data:`, error);
    }
  }
  
  return results;
};

// Exchange Rates API implementation (free, no key required)
const fetchFromExchangeRates = async (pairs: string[]): Promise<Partial<ForexPair>[]> => {
  const results: Partial<ForexPair>[] = [];
  
  try {
    await rateLimitDelay();
    
    // Get USD as base currency
    const response = await axios.get(`${API_CONFIG.EXCHANGE_RATES.baseUrl}/USD`, {
      timeout: 10000
    });

    if (response.data && response.data.rates) {
      const rates = response.data.rates;
      
      for (const pair of pairs) {
        const { base, quote } = formatPairForApi(pair);
        
        let rate = 1;
        
        if (base === 'USD') {
          rate = rates[quote] || 1;
        } else if (quote === 'USD') {
          rate = 1 / (rates[base] || 1);
        } else {
          // Cross currency calculation
          const baseToUsd = 1 / (rates[base] || 1);
          const usdToQuote = rates[quote] || 1;
          rate = baseToUsd * usdToQuote;
        }
        
        // Add some realistic variation
        const variation = (Math.random() - 0.5) * 0.001;
        rate += variation;
        
        const change = (Math.random() - 0.5) * 0.01;
        const changePercent = (change / rate) * 100;
        
        results.push({
          symbol: pair,
          bid: rate - 0.0001,
          ask: rate + 0.0001,
          spread: 0.2,
          change,
          changePercent,
          high: rate * 1.002,
          low: rate * 0.998
        });
      }
    }
  } catch (error) {
    console.error('Error fetching from Exchange Rates API:', error);
  }
  
  return results;
};

// Main function to fetch forex data
export const fetchForexData = async (pairs: string[]): Promise<Partial<ForexPair>[]> => {
  try {
    switch (CURRENT_PROVIDER) {
      case 'ALPHA_VANTAGE':
        return await fetchFromAlphaVantage(pairs);
      case 'TWELVE_DATA':
        return await fetchFromTwelveData(pairs);
      case 'EXCHANGE_RATES':
        return await fetchFromExchangeRates(pairs);
      default:
        throw new Error('Invalid API provider');
    }
  } catch (error) {
    console.error('Error fetching forex data:', error);
    return [];
  }
};

// Function to get historical data for charts (simplified implementation)
export const fetchHistoricalData = async (pair: string, timeframe: string) => {
  // This would require a more sophisticated API call
  // For now, return empty array to maintain existing mock data behavior
  return [];
};

// Health check function
export const checkApiHealth = async (): Promise<boolean> => {
  try {
    const testResult = await fetchForexData(['EURUSD']);
    return testResult.length > 0;
  } catch (error) {
    console.error('API health check failed:', error);
    return false;
  }
};

// Configuration helper
export const getApiInfo = () => {
  const config = API_CONFIG[CURRENT_PROVIDER as keyof typeof API_CONFIG];
  return {
    provider: CURRENT_PROVIDER,
    rateLimit: config.rateLimit,
    requiresApiKey: CURRENT_PROVIDER !== 'EXCHANGE_RATES'
  };
};