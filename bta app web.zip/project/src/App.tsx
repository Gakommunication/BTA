import React, { useState } from 'react';
import Navigation from './components/Navigation';
import Market from './components/Market';
import Charts from './components/Charts';
import NewOrder from './components/NewOrder';
import OpenPositions from './components/OpenPositions';
import TradeHistory from './components/TradeHistory';
import Assistant from './components/Assistant';
import Profile from './components/Profile';
import TradeAnalysis from './components/TradeAnalysis';
import { 
  mockTrades, 
  mockAIMessages, 
  mockProfile, 
  mockForexPairs, 
  mockAccountInfo,
  mockOpenTrades,
  mockClosedTrades
} from './data/mockData';
import { Trade, AIMessage, UserProfile, ForexPair, AccountInfo, TradeAnalysis as TradeAnalysisType } from './types';
import { fetchForexData, checkApiHealth, getApiInfo } from './services/forexApi';

function App() {
  const [currentPage, setCurrentPage] = useState('market');
  const [openTrades, setOpenTrades] = useState<Trade[]>(mockOpenTrades);
  const [closedTrades, setClosedTrades] = useState<Trade[]>(mockClosedTrades);
  const [aiMessages, setAIMessages] = useState<AIMessage[]>(mockAIMessages);
  const [profile, setProfile] = useState<UserProfile>(mockProfile);
  const [forexPairs, setForexPairs] = useState<ForexPair[]>(mockForexPairs);
  const [accountInfo, setAccountInfo] = useState<AccountInfo>(mockAccountInfo);
  const [selectedPair, setSelectedPair] = useState('EURUSD');
  const [selectedTradeForAnalysis, setSelectedTradeForAnalysis] = useState<Trade | null>(null);
  const [apiStatus, setApiStatus] = useState<'connecting' | 'connected' | 'error' | 'fallback'>('connecting');
  const [isPageTransitioning, setIsPageTransitioning] = useState(false);

  // Real-time price updates with API integration
  React.useEffect(() => {
    let interval: NodeJS.Timeout;
    
    const updatePrices = async () => {
      try {
        // Check if API is available
        const isApiHealthy = await checkApiHealth();
        
        if (isApiHealthy) {
          // Fetch real data from API
          const pairSymbols = forexPairs.map(pair => pair.symbol);
          const realData = await fetchForexData(pairSymbols);
          
          if (realData.length > 0) {
            setApiStatus('connected');
            setForexPairs(prev => prev.map(pair => {
              const realPair = realData.find(rp => rp.symbol === pair.symbol);
              if (realPair) {
                return {
                  ...pair,
                  bid: realPair.bid || pair.bid,
                  ask: realPair.ask || pair.ask,
                  change: realPair.change || pair.change,
                  changePercent: realPair.changePercent || pair.changePercent,
                  high: realPair.high || pair.high,
                  low: realPair.low || pair.low,
                  spread: realPair.spread || pair.spread
                };
              }
              return pair;
            }));
          } else {
            throw new Error('No data received from API');
          }
        } else {
          throw new Error('API health check failed');
        }
      } catch (error) {
        console.warn('API fetch failed, using simulated data:', error);
        setApiStatus('fallback');
        
        // Fallback to simulated data
        setForexPairs(prev => prev.map(pair => ({
          ...pair,
          bid: pair.bid + (Math.random() - 0.5) * 0.0001,
          ask: pair.ask + (Math.random() - 0.5) * 0.0001,
          change: pair.change + (Math.random() - 0.5) * 0.0001,
          changePercent: (pair.change / pair.bid) * 100
        })));
      }

      // Update open trades P&L
      setOpenTrades(prev => prev.map(trade => {
        const pair = forexPairs.find(p => p.symbol === trade.pair);
        if (pair) {
          const currentPrice = trade.direction === 'buy' ? pair.bid : pair.ask;
          const pnl = trade.direction === 'buy' 
            ? (currentPrice - (trade.entryPrice || 0)) * (trade.volume || 0.1) * 100000
            : ((trade.entryPrice || 0) - currentPrice) * (trade.volume || 0.1) * 100000;
          
          return {
            ...trade,
            currentPrice,
            pnl: Math.round(pnl * 100) / 100
          };
        }
        return trade;
      }));
    };

    // Initial update
    updatePrices();

    // Set up interval based on API rate limits
    const apiInfo = getApiInfo();
    const updateInterval = Math.max(apiInfo.rateLimit, 5000); // Minimum 5 seconds
    
    interval = setInterval(updatePrices, updateInterval);

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [forexPairs]);

  const handleNewOrder = (orderData: any) => {
    const pair = forexPairs.find(p => p.symbol === orderData.pair);
    if (!pair) return;

    const entryPrice = orderData.orderType === 'market' 
      ? (orderData.direction === 'buy' ? pair.ask : pair.bid)
      : orderData.price;

    const newTrade: Trade = {
      id: Date.now().toString(),
      date: new Date(),
      pair: orderData.pair,
      amount: orderData.volume * 100000,
      volume: orderData.volume,
      direction: orderData.direction,
      reason: orderData.comment || 'No comment',
      status: 'open',
      entryPrice,
      currentPrice: entryPrice,
      stopLoss: orderData.stopLoss,
      takeProfit: orderData.takeProfit,
      pnl: 0,
      orderType: orderData.orderType,
      comment: orderData.comment
    };
    
    setOpenTrades(prev => [newTrade, ...prev]);
    
    // AI message for new trade
    const aiMessage: AIMessage = {
      id: Date.now().toString(),
      content: `Nouvelle position ${orderData.direction === 'buy' ? 'achat' : 'vente'} ouverte sur ${orderData.pair}. Volume: ${orderData.volume} lot. Surveillez votre money management !`,
      timestamp: new Date(),
      type: 'trade',
      tradeId: newTrade.id
    };
    
    setAIMessages(prev => [aiMessage, ...prev]);
  };

  const handleCloseTrade = (tradeId: string) => {
    const trade = openTrades.find(t => t.id === tradeId);
    if (!trade) return;

    const closedTrade: Trade = {
      ...trade,
      status: (trade.pnl || 0) >= 0 ? 'win' : 'loss',
      result: trade.pnl || 0
    };

    setOpenTrades(prev => prev.filter(t => t.id !== tradeId));
    setClosedTrades(prev => [closedTrade, ...prev]);

    // AI message for closed trade
    const aiMessage: AIMessage = {
      id: Date.now().toString(),
      content: closedTrade.status === 'win' 
        ? `Félicitations ! Trade fermé avec un profit de ${closedTrade.result}$. Excellente gestion !`
        : `Trade fermé avec une perte de ${closedTrade.result}$. Analysez ce qui s'est passé pour vous améliorer.`,
      timestamp: new Date(),
      type: closedTrade.status === 'win' ? 'motivation' : 'analysis',
      tradeId: closedTrade.id
    };
    
    setAIMessages(prev => [aiMessage, ...prev]);
  };

  const handleTradeAnalysis = (analysis: TradeAnalysisType) => {
    setClosedTrades(prev => prev.map(trade => 
      trade.id === analysis.tradeId 
        ? { ...trade, analysis }
        : trade
    ));
    setSelectedTradeForAnalysis(null);
  };

  const handleProfileUpdate = (newProfile: UserProfile) => {
    setProfile(newProfile);
  };

  // Smooth page transitions
  const handlePageChange = (page: string) => {
    if (page === currentPage) return;
    
    setIsPageTransitioning(true);
    
    // Add haptic feedback simulation
    if (navigator.vibrate) {
      navigator.vibrate(10);
    }
    
    setTimeout(() => {
      setCurrentPage(page);
      setIsPageTransitioning(false);
    }, 150);
  };

  const renderCurrentPage = () => {
    const pageClass = `page-transition ${isPageTransitioning ? 'opacity-0 scale-95' : 'opacity-100 scale-100'}`;
    
    switch (currentPage) {
      case 'market':
        return (
          <div className={pageClass}>
            <Market
              forexPairs={forexPairs}
              accountInfo={accountInfo}
              selectedPair={selectedPair}
              onSelectPair={setSelectedPair}
              onNewOrder={() => handlePageChange('new-order')}
              apiStatus={apiStatus}
            />
          </div>
        );
      case 'charts':
        return (
          <div className={pageClass}>
            <Charts
              selectedPair={selectedPair}
              onSelectPair={setSelectedPair}
              openTrades={openTrades}
            />
          </div>
        );
      case 'new-order':
        return (
          <div className={pageClass}>
            <NewOrder
              selectedPair={selectedPair}
              forexPairs={forexPairs}
              onBack={() => handlePageChange('market')}
              onOrderSubmitted={handleNewOrder}
            />
          </div>
        );
      case 'positions':
        return (
          <div className={pageClass}>
            <OpenPositions
              trades={openTrades}
              onCloseTrade={handleCloseTrade}
            />
          </div>
        );
      case 'history':
        return (
          <div className={pageClass}>
            <TradeHistory
              trades={closedTrades}
              onAnalyzeTrade={setSelectedTradeForAnalysis}
            />
          </div>
        );
      case 'assistant':
        return (
          <div className={pageClass}>
            <Assistant messages={aiMessages} />
          </div>
        );
      case 'profile':
        return (
          <div className={pageClass}>
            <Profile
              profile={profile}
              onProfileUpdate={handleProfileUpdate}
            />
          </div>
        );
      default:
        return (
          <div className={pageClass}>
            <Market
              forexPairs={forexPairs}
              accountInfo={accountInfo}
              selectedPair={selectedPair}
              onSelectPair={setSelectedPair}
              onNewOrder={() => handlePageChange('new-order')}
              apiStatus={apiStatus}
            />
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 overflow-hidden">
      {/* Main content with optimized spacing */}
      <main className="w-full pt-16 pb-32 custom-scrollbar smooth-scroll">
        {renderCurrentPage()}
      </main>
      
      {/* Trade Analysis Modal */}
      {selectedTradeForAnalysis && (
        <TradeAnalysis
          trade={selectedTradeForAnalysis}
          onClose={() => setSelectedTradeForAnalysis(null)}
          onSubmit={handleTradeAnalysis}
        />
      )}
      
      {/* Navigation */}
      <Navigation currentPage={currentPage} onPageChange={handlePageChange} />
    </div>
  );
}

export default App;