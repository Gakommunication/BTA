export interface Trade {
  id: string;
  date: Date;
  pair: string;
  amount: number;
  direction: 'buy' | 'sell';
  reason: string;
  status: 'pending' | 'win' | 'loss' | 'open';
  result?: number;
  aiMessage?: string;
  entryPrice?: number;
  stopLoss?: number;
  takeProfit?: number;
  currentPrice?: number;
  pnl?: number;
  orderType?: 'market' | 'limit' | 'stop';
  volume?: number;
  comment?: string;
  analysis?: TradeAnalysis;
}

export interface TradeAnalysis {
  id: string;
  tradeId: string;
  rating: number; // 1-5 stars
  emotionalState: 'calm' | 'stressed' | 'euphoric' | 'frustrated';
  reason: string;
  lesson: string;
  attachments: TradeAttachment[];
  createdAt: Date;
}

export interface TradeAttachment {
  id: string;
  type: 'image' | 'audio' | 'document';
  name: string;
  url: string;
  size: number;
}

export interface UserProfile {
  level: 'beginner' | 'intermediate' | 'advanced';
  dailyGoal: number;
  tradingStyle: 'scalping' | 'intraday' | 'swing' | 'position';
  weeklyGoal?: number;
  goalType: 'daily' | 'weekly';
}

export interface AIMessage {
  id: string;
  content: string;
  timestamp: Date;
  type: 'trade' | 'general' | 'motivation' | 'warning' | 'analysis';
  tradeId?: string;
}

export interface ForexPair {
  symbol: string;
  name: string;
  bid: number;
  ask: number;
  spread: number;
  change: number;
  changePercent: number;
  high: number;
  low: number;
}

export interface AccountInfo {
  balance: number;
  equity: number;
  margin: number;
  freeMargin: number;
  marginLevel: number;
}

export interface ChartData {
  timestamp: Date;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export type Timeframe = 'M1' | 'M5' | 'M15' | 'H1' | 'H4' | 'D1';